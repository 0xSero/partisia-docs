use std::collections::BTreeMap;
use std::error::Error;
use std::fs::File;
use std::io::Write;

use pbc_contract_common::abi::contract::ContractAbi;
use pbc_contract_common::abi::func::FnAbi;
use pbc_contract_common::abi::types::TypeAbi;
use pbc_contract_common::abi::{abi_header_bytes, TypeKey};
use pbc_traits::ReadWriteState;
use wasmtime::*;

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() != 3 {
        println!("Usage: pbc-abigen <wasm> <abi output>");
        return Err("Missing arguments".into());
    }

    let wasm = &args[1];
    let bin = &args[2];
    read_wasm_and_write_json(wasm, bin)
}

fn read_wasm_and_write_json(wasm_file: &str, bin_file: &str) -> Result<(), Box<dyn Error>> {
    let engine = Engine::default();
    let module = Module::from_file(&engine, wasm_file)?;

    let mut store = Store::new(&engine, "");
    let mut linker = Linker::new(&engine);

    linker
        .func_wrap("ext", "read_context_into_address", |_p0: i64, _p1: i32| 0)
        .expect("Failed to wrap function");
    linker
        .func_wrap(
            "ext",
            "call_named",
            |_p0: i64, _p1: i32, _p2: i64, _p3: i32| {},
        )
        .expect("failed to wrap function call_named");
    linker
        .func_wrap("ext", "log_external", |_p0: i64, _p1: i32| {})
        .expect("failed to wrap function call_named");

    let instance = linker.instantiate(&mut store, &module)?;
    let memory = instance.get_memory(&mut store, "memory").unwrap();

    let old_size = memory.size(&store);
    // Allocate 640k ram
    memory.grow(&mut store, 100).unwrap();

    let mut base_pointer = (old_size * 65536) as i32;

    let lut_pointer = base_pointer;

    {
        let mut out: Vec<u8> = Vec::new();
        let lut: BTreeMap<TypeKey, u8> = BTreeMap::new();
        lut.state_write_to(&mut out).unwrap();

        memory.write(&mut store, base_pointer as usize, &out)?;

        base_pointer += out.len() as i32;
    }

    let mut types: Vec<TypeAbi> = Vec::new();
    for export in module.exports() {
        let export_name = export.name();
        if export_name.starts_with("abi_type_") {
            println!("Pass 1: Reading type abi: {}", export_name);
            let abi_type = get_fun_or_panic(&instance, &mut store, export_name);

            let type_abi: TypeAbi =
                read_from_ffi(&mut store, base_pointer, &memory, abi_type, lut_pointer);
            types.push(type_abi)
        }
    }

    println!("Pass 1: Writing lut");
    let mut lut: BTreeMap<TypeKey, u8> = BTreeMap::new();
    for (index, type_abi) in types.iter().enumerate() {
        println!("Inserting lut {}, {}", type_abi.name, index);
        lut.insert(type_abi.type_key.clone(), index as u8);
    }

    let lut_pointer = base_pointer;
    {
        let mut out: Vec<u8> = Vec::new();
        lut.state_write_to(&mut out).unwrap();

        memory.write(&mut store, base_pointer as usize, &out)?;

        base_pointer += out.len() as i32;
    }

    println!("Pass 2: Begin lut");
    let mut types: Vec<TypeAbi> = Vec::new();
    let mut actions: Vec<FnAbi> = Vec::new();
    for export in module.exports() {
        let export_name = export.name();
        if export_name.starts_with("abi_type_") {
            println!("Pass 2: Reading type abi: {}", export_name);
            let abi_type = get_fun_or_panic(&instance, &mut store, export_name);

            let type_abi: TypeAbi =
                read_from_ffi(&mut store, base_pointer, &memory, abi_type, lut_pointer);
            types.push(type_abi)
        }

        if export_name.starts_with("abi_func_") {
            println!("Pass 2: Reading function abi: {}", export_name);
            let abi_fn = get_fun_or_panic(&instance, &mut store, export_name);
            let fn_abi: FnAbi =
                read_from_ffi(&mut store, base_pointer, &memory, abi_fn, lut_pointer);
            actions.push(fn_abi);
        }
    }

    println!("Reading state name");
    let state_name_fn = get_fun_or_panic(&instance, &mut store, "__abi_state_name");
    let state: String = read_from_ffi(
        &mut store,
        base_pointer,
        &memory,
        state_name_fn,
        lut_pointer,
    );
    println!("Read state name: {}", state);

    println!("Reading init function abi");
    let init_abi_fn = get_fun_or_panic(&instance, &mut store, "__abi_func_init_to_ptr");
    let init: FnAbi = read_from_ffi(&mut store, base_pointer, &memory, init_abi_fn, lut_pointer);

    let potential_state_indices: Vec<usize> = types
        .iter()
        .enumerate()
        .filter(|(_, type_abi)| type_abi.name == state)
        .map(|(idx, _)| idx)
        .collect();

    assert_eq!(
        potential_state_indices.len(),
        1,
        "More than one type named {}",
        state
    );

    let state_index = potential_state_indices.get(0).cloned().unwrap();

    let state_type: &TypeAbi = types.get(state_index).unwrap();
    let mut ordinals = state_type.type_key.ordinals.clone();
    if ordinals[0] == 0 {
        ordinals.insert(0, 0);
    }

    let mut contract = ContractAbi::new(init, ordinals);
    contract.actions(actions);
    contract.types(types);

    write_as_binary(&contract, bin_file)?;

    Ok(())
}

fn write_as_binary(contract: &ContractAbi, filename: &str) -> std::io::Result<()> {
    let mut file = File::create(filename.to_string())?;
    file.write_all(&abi_header_bytes(1))?;
    contract.serialize_abi(&mut file)
}

fn read_from_ffi<T: ReadWriteState>(
    mut store: &mut Store<&str>,
    base_pointer: i32,
    memory: &Memory,
    wasm_fn: Func,
    lut_pointer: i32,
) -> T {
    println!("Calling {:?}", wasm_fn);
    let size = wasm_fn
        .call(&mut store, &[Val::I32(base_pointer), Val::I32(lut_pointer)])
        .expect("Call failed");
    let usize_size = size.first().unwrap().i32().unwrap() as usize;

    let base_pointer_native = base_pointer as usize;
    let mut content_buffer =
        &memory.data(&store)[base_pointer_native..base_pointer_native + usize_size];
    return T::state_read_from(&mut content_buffer);
}

fn get_fun_or_panic(instance: &Instance, store: &mut Store<&str>, export_name: &str) -> Func {
    instance
        .get_func(store, export_name)
        .unwrap_or_else(|| panic!("{} is not an exported function", export_name))
}
