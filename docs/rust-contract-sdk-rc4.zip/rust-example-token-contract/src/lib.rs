#![allow(unused_variables)]

#[macro_use]
extern crate pbc_contract_codegen;

use std::collections::BTreeMap;
use std::convert::TryInto;
use std::io::{Read, Write};

use pbc_contract_common::address::Address;
use pbc_contract_common::context::ContractContext;
use pbc_traits::{ReadInt, ReadWriteRPC, ReadWriteState};

#[state]
pub struct TokenContractState {
    symbol: [u8; 16],
    owner: Address,
    total_supply: u64,
    balances: BTreeMap<Address, u64>,
}

impl TokenContractState {
    fn update_balance(&mut self, address: Address, delta: i64) {
        let balance = self.balances.entry(address).or_insert(0);
        if delta < 0 {
            *balance = ((*balance as i64) + delta) as u64;
        } else {
            *balance += delta as u64;
        }
    }

    fn update_total_supply(&mut self, delta: i64) {
        if delta < 0 {
            self.total_supply = ((self.total_supply as i64) + delta) as u64;
        } else {
            self.total_supply += delta as u64;
        }
    }

    fn get_balance(&self, address: Address) -> u64 {
        if let Some(balance) = self.balances.get(&address) {
            *balance
        } else {
            0
        }
    }
}

#[init]
pub fn initialize(ctx: ContractContext, total_supply: u64) -> TokenContractState {
    let mut balances = BTreeMap::new();
    balances.insert(ctx.sender, total_supply);
    TokenContractState {
        symbol: [0; 16],
        owner: ctx.sender,
        total_supply,
        balances,
    }
}

#[action]
pub fn mint(
    context: ContractContext,
    state: TokenContractState,
    amount: u64,
) -> TokenContractState {
    assert_eq!(context.sender, state.owner, "Mint only allowed for owner.");
    let mut new_state = state.clone();
    new_state.update_balance(state.owner, amount.try_into().unwrap());
    new_state.update_total_supply(amount.try_into().unwrap());
    new_state
}

#[action]
pub fn transfer(
    context: ContractContext,
    state: TokenContractState,
    dest: Address,
    amount: u64,
) -> TokenContractState {
    let mut new_state = state;
    assert!(
        new_state.get_balance(context.sender) >= amount,
        "Amount > balance"
    );

    let delta = amount.try_into().unwrap();
    new_state.update_balance(dest, delta);
    new_state.update_balance(context.sender, -delta);
    new_state
}
