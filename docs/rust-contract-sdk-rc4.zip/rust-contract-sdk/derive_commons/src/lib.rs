extern crate proc_macro;
#[macro_use]
extern crate quote;
extern crate syn;

use quote::ToTokens;
use syn::__private::TokenStream2;
use syn::parse_quote::parse;
use syn::{Data, Expr, Field, Fields, Ident, Type};

pub fn field_to_name(field: &Field) -> Ident {
    field.ident.clone().unwrap()
}

pub fn impl_read_write(
    ast: &syn::DeriveInput,
    trait_name: Ident,
    read_method: Ident,
    write_method: Ident,
) -> proc_macro2::TokenStream {
    let name = &ast.ident;
    let fieldnames = fields_to_names(&ast.data);
    let (readlines, writelines) = make_read_and_write_lines(&ast.data, &read_method, &write_method);

    let implementation = quote! {
        impl pbc_traits::#trait_name for #name {
            fn #read_method<T: Read>(reader: &mut T) -> Self {
                #readlines
                #name {
                    #(#fieldnames),*
                }
            }

            fn #write_method<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
                #writelines
            }
        }
    };
    implementation
}

pub fn field_to_type(field: &Field) -> TokenStream2 {
    let ty: TokenStream2 = match &field.ty {
        Type::Path(path) => path.clone().to_token_stream(),
        Type::Array(arr) => {
            let ident = match arr.elem.as_ref() {
                Type::Path(p) => p
                    .path
                    .segments
                    .last()
                    .unwrap()
                    .clone()
                    .ident
                    .to_token_stream(),
                _ => unimplemented!("Not implemented"),
            };

            let len = match &arr.len {
                Expr::Lit(arrws) => Some(arrws.lit.to_token_stream()),
                _ => unimplemented!("Not implemented"),
            };

            parse(quote!([#ident; #len]))
        }
        _ => unimplemented!("Unknown type."),
    };
    ty.to_token_stream()
}

fn fields_to_names(data: &Data) -> Vec<Ident> {
    let list_of_names: Vec<Ident> = match *data {
        Data::Struct(ref data) => match data.fields {
            Fields::Named(ref fields) => fields.named.iter().map(field_to_name).collect(),
            _ => unimplemented!("Only named fields are supported"),
        },
        _ => unimplemented!("Only structs are supported"),
    };

    list_of_names
}

fn make_read_and_write_lines(
    data: &Data,
    read_method: &Ident,
    write_method: &Ident,
) -> (proc_macro2::TokenStream, proc_macro2::TokenStream) {
    match *data {
        Data::Struct(ref data) => match data.fields {
            Fields::Named(ref fields) => {
                let names: Vec<Ident> = fields.named.iter().map(field_to_name).collect();
                let types: Vec<TokenStream2> = fields.named.iter().map(field_to_type).collect();
                let read_lines = quote! {
                    #(
                        let #names =  <#types>::#read_method(reader);
                    )*
                };

                let write_lines = quote! {
                    #(
                        <#types>::#write_method(&self.#names, writer)?;
                    )*
                    return Ok(());
                };

                (read_lines, write_lines)
            }
            _ => unimplemented!("Only named fields are supported"),
        },
        _ => unimplemented!("Only structs are supported"),
    }
}
