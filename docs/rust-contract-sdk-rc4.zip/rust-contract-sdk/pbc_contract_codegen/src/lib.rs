#![recursion_limit = "128"]
extern crate pbc_external;
extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate sha2;
extern crate syn;

use proc_macro::TokenStream;

use proc_macro2::Span;
use quote::ToTokens;
use syn::__private::TokenStream2;
use syn::{FnArg, Ident, Item, Type, TypePath};

use pbc_contract_common::abi::func::name_to_shortname_as_string;

#[proc_macro_attribute]
pub fn state(_attrs: TokenStream, input: TokenStream) -> TokenStream {
    let original_state_item: proc_macro2::TokenStream = input.clone().into();
    let parsed_item: Item = syn::parse(input).unwrap();

    let state_struct_name = match parsed_item {
        Item::Struct(i) => i.ident.to_string(),
        _ => unimplemented!("The state attribute is only valid for structs."),
    };

    let result = quote! {
        use create_type_derive::CreateType as InternalDeriveCreateType;
        use read_write_state_derive::ReadWriteState as InternalDeriveReadWriteState;

        #[repr(C)]
        #[derive(Clone, InternalDeriveCreateType, InternalDeriveReadWriteState )]
        #original_state_item

        #[doc = "ABI: Name of the state struct"]
        #[no_mangle]
        #[allow(clippy::not_unsafe_ptr_arg_deref)]
        pub extern "C" fn __abi_state_name(dst_ptr: *mut u8, _unused_lut_ptr: *mut u8) -> usize {
            let state_name = #state_struct_name.to_string();

            let mut out:Vec<u8> = Vec::with_capacity(state_name.len());
            state_name.state_write_to(&mut out).unwrap();

            unsafe { std::ptr::copy(out.as_ptr(), dst_ptr, out.len()) };
            out.len()
        }
    };

    result.into()
}

#[proc_macro_attribute]
pub fn init(_attrs: TokenStream, input: TokenStream) -> TokenStream {
    let fn_ast: syn::ItemFn = syn::parse(input.clone()).unwrap();
    // TODO [tth] validate that the first argument is contract context.
    // TODO [tth] validate that the return type is "state".

    let (
        ctx_name,
        ctx_expression,
        state_name,
        state_expression,
        rpc_param_names,
        rpc_param_expressions,
    ) = variables_for_inner_call(&fn_ast, true);

    let fn_identifier = fn_ast.sig.ident.clone();
    let export_symbol = format_ident!("init");
    let export_symbol_upper = format_ident!("INIT");
    let raw_fn_name = fn_identifier.to_string();
    let docs = format!("For contract initializer: {}", raw_fn_name);

    let mut result = wrap_function_for_export(
        fn_identifier,
        export_symbol,
        export_symbol_upper,
        docs,
        ctx_name,
        ctx_expression,
        state_name,
        state_expression,
        rpc_param_names,
        rpc_param_expressions,
    );

    let (names, types_as_string) = read_arguments(&fn_ast, 1);
    let types_as_ident: Vec<TokenStream2> = types_as_string.into_iter().collect();

    let internal_abi_fn = quote! {
        #[doc = "ABI: Init function abi"]
        #[no_mangle]
        pub extern "C" fn __abi_func_init_to_ptr(ptr: *mut u8, lut_ptr: *mut u8) -> u32 {
            let lut = pbc_contract_common::read_lut_from_ptr(lut_ptr);
            let mut fn_abi = pbc_contract_common::abi::func::FnAbi::new(#raw_fn_name.to_string());
            #(fn_abi.argument::<#types_as_ident>(#names.to_string(), &lut);)*
            pbc_contract_common::abi_to_ptr(fn_abi, ptr)
        }
    };

    result.extend(internal_abi_fn);
    result.extend(TokenStream2::from(input));
    result.into()
}

#[proc_macro_attribute]
pub fn action(_attrs: TokenStream, input: TokenStream) -> TokenStream {
    let fn_ast: syn::ItemFn = syn::parse(input.clone()).unwrap();

    let (
        ctx_name,
        ctx_expression,
        state_name,
        state_expression,
        rpc_param_names,
        rpc_param_expressions,
    ) = variables_for_inner_call(&fn_ast, false);

    let fn_identifier = fn_ast.sig.ident.clone();
    let (names, types) = read_arguments(&fn_ast, 2);

    let fn_name = &fn_identifier.to_string();
    let shortname = name_to_shortname_as_string(fn_name);
    let to_ptr_stream = make_fn_to_ptr_stream(shortname.as_str());
    let func_stream = make_func(fn_name, shortname.as_str(), names, types);

    let export_symbol = format_ident!("action_{}", shortname);
    let export_symbol_upper = format_ident!("action_{}", shortname.to_uppercase());
    let raw_fn_name = fn_identifier.to_string();
    let docs = format!("For contract action: {}", raw_fn_name);

    let mut result = wrap_function_for_export(
        fn_identifier,
        export_symbol,
        export_symbol_upper,
        docs,
        ctx_name,
        ctx_expression,
        state_name,
        state_expression,
        rpc_param_names,
        rpc_param_expressions,
    );

    result.extend(TokenStream2::from(input));
    result.extend(func_stream);
    result.extend(to_ptr_stream);
    result.into()
}

#[proc_macro_attribute]
pub fn abi_type(_attrs: TokenStream, input: TokenStream) -> TokenStream {
    let type_ast: syn::ItemFn = syn::parse(input).unwrap();
    let type_identifier = type_ast.sig.ident.clone();
    let struct_name = type_identifier.to_string();
    let (names, types) = read_arguments(&type_ast, 0);
    let type_fn = make_type(&struct_name, names, types);
    let type_to_ptr = make_type_to_ptr_stream(&struct_name);
    let mut result = TokenStream2::new();
    result.extend(type_fn);
    result.extend(type_to_ptr);
    result.into()
}

fn make_type(
    type_name: &str,
    fieldnames: Vec<String>,
    fieldtypes: Vec<TokenStream2>,
) -> TokenStream2 {
    let name = format_ident!("abi_type_{}", type_name);
    let result = quote! {
        pub fn #name(lut_ptr: *mut u8 ) -> pbc_contract_common::abi::types::TypeAbi {
            let lut = pbc_contract_common::read_lut_from_ptr(lut_ptr);

            let mut ty = pbc_contract_common::abi::types::TypeAbi::new(#type_name);
            #(ty.field(#fieldnames, #fieldtypes);)*
            ty
        }
    };
    result
}

fn make_type_to_ptr_stream(typename: &str) -> proc_macro2::TokenStream {
    let funccall = format_ident!("abi_type_{}", typename);
    let variablefunc = format_ident!("v_{}_abi", typename);
    let funcname = format_ident!("abi_type_{}_to_ptr", typename);
    let result = quote! {
        #[no_mangle]
        pub extern "C" fn #funcname(ptr: *mut u8) -> u32 {
            let #variablefunc = #funccall();
            pbc_contract_common::abi_to_ptr(#typename, ptr)
        }
    };
    result
}

fn make_func(
    fn_name: &str,
    shortname: &str,
    params: Vec<String>,
    types: Vec<TokenStream2>,
) -> TokenStream2 {
    let name = format_ident!("abi_{}", shortname);

    let result = quote! {
        pub fn #name(lut_ptr: *mut u8) -> pbc_contract_common::abi::func::FnAbi {
            let lut = pbc_contract_common::read_lut_from_ptr(lut_ptr);

            let mut fn_abi = pbc_contract_common::abi::func::FnAbi::new(#fn_name.to_string());
            #(fn_abi.argument::<#types>(#params.to_string(), &lut);)*
            fn_abi
        }
    };
    result
}

fn make_fn_to_ptr_stream(shortname: &str) -> proc_macro2::TokenStream {
    let funccall = format_ident!("abi_{}", shortname);
    let variablefunc = format_ident!("v_{}_abi", shortname);
    let funcname = format_ident!("abi_func_{}_to_ptr", shortname);
    let result = quote! {
        #[no_mangle]
        pub extern "C" fn #funcname(ptr: *mut u8, lut_ptr: *mut u8) -> u32 {
            let #variablefunc = #funccall(lut_ptr);
            pbc_contract_common::abi_to_ptr(#variablefunc, ptr)
        }
    };
    result
}

#[allow(clippy::too_many_arguments)]
fn wrap_function_for_export(
    fn_identifier: Ident,
    export_symbol: Ident,
    upper: Ident,
    docs: String,
    _ctx_name: TokenStream2,
    ctx_expression: TokenStream2,
    state_name: Option<TokenStream2>,
    state_expression: Option<TokenStream2>,
    rpc_parameter_names: Vec<TokenStream2>,
    rpc_parameter_expressions: Vec<TokenStream2>,
) -> TokenStream2 {
    if state_name.is_some() && state_expression.is_some() {
        quote! {
            #[allow(clippy::not_unsafe_ptr_arg_deref)]
            #[doc = #docs]
            #[no_mangle]
            pub extern "C" fn #export_symbol(
                ctx_ptr: *const u8, ctx_len: usize,
                state_ptr: *const u8, state_len: usize,
                rpc_ptr: *const u8, rpc_len: usize
            ) -> i64 {
                use pbc_traits::ReadWriteState;
                use pbc_traits::ReadInt;

                let rpc = unsafe { std::slice::from_raw_parts(rpc_ptr, rpc_len as usize).to_owned() };
                let mut rpc_reader = std::io::Cursor::new(rpc);

                // The expressions, which are used to evaluate the arguments for the inner function,
                // deserialize from "cursor" meaning they have side effects.
                // Because of this, we need to ensure that they are evaluated in the correct order,
                // thus we will bind them to variables instead of #fn_identifier(#(#expression),*)
                // (since function arguments are not guaranteed to evaluate left to right).
                #(let #rpc_parameter_names = #rpc_parameter_expressions)*


                let ctx = unsafe { std::slice::from_raw_parts(ctx_ptr, ctx_len as usize).to_owned() };
                let mut ctx_reader = std::io::Cursor::new(ctx);

                let state_slice = unsafe { std::slice::from_raw_parts(state_ptr, state_len as usize).to_owned() };
                let mut state_reader = std::io::Cursor::new(state_slice);

                let context = #ctx_expression;
                let prev_state = #state_expression;

                let state = #fn_identifier(context, prev_state, #(#rpc_parameter_names),*);

                let mut method_result: Vec<u8> = Vec::new();
                state.state_write_to(&mut method_result).unwrap();

                let len = method_result.len() as i64;
                let ptr = method_result.as_ptr() as i64;
                std::mem::forget(method_result);

                len << 32 | ptr
            }

            #[allow(clippy::not_unsafe_ptr_arg_deref)]
            #[doc = #docs]
            #[no_mangle]
            pub extern "C" fn #upper(
                ctx_ptr: *const u8, ctx_len: usize,
                state_ptr: *const u8, state_len: usize,
                rpc_ptr: *const u8, rpc_len: usize
            ) -> i64 {
                #export_symbol(ctx_ptr, ctx_len, state_ptr, state_len, rpc_ptr, rpc_len)
            }
        }
    } else {
        quote! {
            #[allow(clippy::not_unsafe_ptr_arg_deref)]
            #[doc = #docs]
            #[no_mangle]
            pub extern "C" fn #export_symbol(
                ctx_ptr: *const u8, ctx_len: usize,
                rpc_ptr: *const u8, rpc_len: usize
            ) -> i64 {
                let rpc = unsafe { std::slice::from_raw_parts(rpc_ptr, rpc_len as usize).to_owned() };
                let mut rpc_reader = std::io::Cursor::new(rpc);

                // The expressions, which are used to evaluate the arguments for the inner function,
                // deserialize from "cursor" meaning they have side effects.
                // Because of this, we need to ensure that they are evaluated in the correct order,
                // thus we will bind them to variables instead of #fn_identifier(#(#expression),*)
                // (since function arguments are not guaranteed to evaluate left to right).
                #(let #rpc_parameter_names = #rpc_parameter_expressions)*


                let ctx = unsafe { std::slice::from_raw_parts(ctx_ptr, ctx_len as usize).to_owned() };
                let mut ctx_reader = std::io::Cursor::new(ctx);

                let context = #ctx_expression;

                let state = #fn_identifier(context,  #(#rpc_parameter_names),*);

                let mut method_result: Vec<u8> = Vec::new();
                state.state_write_to(&mut method_result).unwrap();

                let len = method_result.len() as i64;
                let ptr = method_result.as_ptr() as i64;
                std::mem::forget(method_result);

                len << 32 | ptr
            }
        }
    }
}

fn read_arguments(item: &syn::ItemFn, skip: usize) -> (Vec<String>, Vec<TokenStream2>) {
    let mut names = Vec::new();
    let mut types = Vec::new();
    for token in item.sig.inputs.iter() {
        match token {
            FnArg::Receiver(_) => {
                panic!("Contract functions cannot be part of an `impl`.")
            }
            FnArg::Typed(pat) => {
                let identifier = pat.pat.to_token_stream();
                let ty = pat.ty.to_token_stream();
                names.push(identifier.to_string());
                types.push(ty);
            }
        }
    }

    (names.split_off(skip), types.split_off(skip))
}

fn variables_for_inner_call(
    item: &syn::ItemFn,
    is_init: bool,
) -> (
    TokenStream2,
    TokenStream2,
    Option<TokenStream2>,
    Option<TokenStream2>,
    Vec<TokenStream2>,
    Vec<TokenStream2>,
) {
    let mut var_name: Vec<TokenStream2> = Vec::new();
    let mut expression: Vec<TokenStream2> = Vec::new();

    let mut iter = item.sig.inputs.iter();

    let (ctx_name, ctx_expression) = extract_name_and_expression_to_streams(
        format_ident!("ctx_reader"),
        iter.next().unwrap(),
        true,
    );
    let (state_name, state_expression) = if is_init {
        (None, None)
    } else {
        let (a, b) = extract_name_and_expression_to_streams(
            format_ident!("state_reader"),
            iter.next().unwrap(),
            true,
        );
        (Some(a), Some(b))
    };

    for token in iter {
        let reader_ident = format_ident!("rpc_reader");
        let (name, expr) = extract_name_and_expression_to_streams(reader_ident, token, false);
        var_name.push(name);
        expression.push(expr);
    }

    (
        ctx_name,
        ctx_expression,
        state_name,
        state_expression,
        var_name,
        expression,
    )
}

fn extract_name_and_expression_to_streams(
    reader_ident: Ident,
    token: &FnArg,
    state_flag: bool,
) -> (TokenStream2, TokenStream2) {
    match token {
        FnArg::Receiver(_) => {
            // TODO [tth]: Note that self receivers with a specified type,
            //  such as self: Box<Self>, are parsed as a FnArg::Typed.
            panic!("Contract functions cannot be part of an `impl`.")
        }
        FnArg::Typed(pat) => {
            let name = pat.pat.to_token_stream().to_string();
            let variable_identifier = format_ident!("tmp_{}", name);
            let var_name = quote! {#variable_identifier};
            let ty = *(pat.ty.clone());
            match ty {
                Type::Path(path) => {
                    let expr = generate_instantiating_expression(reader_ident, path, state_flag);
                    (var_name, expr)
                }
                Type::Tuple(_) => {
                    panic!("Unsupported tuple type");
                }
                Type::Array(_) => {
                    panic!("Unsupported array type");
                }
                Type::ImplTrait(_) => {
                    panic!("Unsupported impl trait type");
                }
                Type::Reference(_) => {
                    panic!("Unsupported reference type");
                }
                Type::Slice(_) => {
                    panic!("Unsupported slice type");
                }
                _ => {
                    panic!("Unsupported argument type")
                }
            }
        }
    }
}

fn generate_instantiating_expression(
    reader_ident: Ident,
    path: TypePath,
    state_flag: bool,
) -> TokenStream2 {
    let readfrom = if state_flag {
        format_ident!("state_read_from")
    } else {
        format_ident!("rpc_read_from")
    };
    match path.path.get_ident() {
        Some(ident) => {
            if ident.eq(&Ident::new("u64", Span::call_site())) {
                quote! {#reader_ident.read_u64_be();}
            } else if ident.eq(&Ident::new("i64", Span::call_site())) {
                quote! {#reader_ident.read_i64_be();}
            } else if ident.eq(&Ident::new("i32", Span::call_site())) {
                quote! {#reader_ident.read_i32_be();}
            } else {
                quote! {<#ident>::#readfrom(&mut #reader_ident);}
            }
        }
        None => {
            let tokens = path.path.segments.into_token_stream();
            quote! {<#tokens>::#readfrom(&mut #reader_ident);}
        }
    }
}

#[cfg(test)]
mod test {
    #[test]
    fn failing_actions() {
        let t = trybuild::TestCases::new();
        t.compile_fail("tests/action/fail/*.rs");
    }
}
