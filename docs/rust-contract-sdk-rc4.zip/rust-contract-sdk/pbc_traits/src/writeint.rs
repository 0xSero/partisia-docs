use std::io::Write;

/// A trait that specifies functions for writing integers in both big and little endian.
pub trait WriteInt {
    fn write_i128_be(&mut self, val: i128) -> std::io::Result<()>;
    fn write_i128_le(&mut self, val: i128) -> std::io::Result<()>;

    fn write_u128_be(&mut self, val: u128) -> std::io::Result<()>;
    fn write_u128_le(&mut self, val: u128) -> std::io::Result<()>;

    fn write_i64_be(&mut self, val: i64) -> std::io::Result<()>;
    fn write_i64_le(&mut self, val: i64) -> std::io::Result<()>;

    fn write_u64_be(&mut self, val: u64) -> std::io::Result<()>;
    fn write_u64_le(&mut self, val: u64) -> std::io::Result<()>;

    fn write_i32_be(&mut self, val: i32) -> std::io::Result<()>;
    fn write_i32_le(&mut self, val: i32) -> std::io::Result<()>;

    fn write_u32_be(&mut self, val: u32) -> std::io::Result<()>;
    fn write_u32_le(&mut self, val: u32) -> std::io::Result<()>;

    fn write_i16_be(&mut self, val: i16) -> std::io::Result<()>;
    fn write_i16_le(&mut self, val: i16) -> std::io::Result<()>;

    fn write_u16_be(&mut self, val: u16) -> std::io::Result<()>;
    fn write_u16_le(&mut self, val: u16) -> std::io::Result<()>;

    fn write_i8(&mut self, val: i8) -> std::io::Result<()>;
    fn write_u8(&mut self, val: u8) -> std::io::Result<()>;
}

/// A macro for implementing integer writes using the <type>::to_be_bytes or le_bytes methods.
macro_rules! write_int {
    ($($type:ty, $fn_name:ident, $convert:ident)*) => {
        $(
            fn $fn_name(&mut self, val: $type) -> std::io::Result<()> {
                let buf = <$type>::$convert(val);
                self.write_all(&buf)
            }
        )*
    }
}

impl<T: Write> WriteInt for T {
    write_int!(u128, write_u128_be, to_be_bytes);
    write_int!(u128, write_u128_le, to_le_bytes);
    write_int!(i128, write_i128_be, to_be_bytes);
    write_int!(i128, write_i128_le, to_le_bytes);

    write_int!(u64, write_u64_be, to_be_bytes);
    write_int!(u64, write_u64_le, to_le_bytes);
    write_int!(i64, write_i64_be, to_be_bytes);
    write_int!(i64, write_i64_le, to_le_bytes);

    write_int!(u32, write_u32_be, to_be_bytes);
    write_int!(u32, write_u32_le, to_le_bytes);
    write_int!(i32, write_i32_be, to_be_bytes);
    write_int!(i32, write_i32_le, to_le_bytes);

    write_int!(u16, write_u16_be, to_be_bytes);
    write_int!(u16, write_u16_le, to_le_bytes);
    write_int!(i16, write_i16_be, to_be_bytes);
    write_int!(i16, write_i16_le, to_le_bytes);

    write_int!(u8, write_u8, to_be_bytes);
    write_int!(i8, write_i8, to_be_bytes);
}
