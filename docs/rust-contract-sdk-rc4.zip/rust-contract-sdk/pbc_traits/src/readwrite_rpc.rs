use std::io::{Read, Write};

use crate::readint::ReadInt;
use crate::writeint::WriteInt;

pub trait ReadWriteRPC: Sized {
    fn rpc_read_from<T: Read>(reader: &mut T) -> Self;
    fn rpc_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()>;
}

impl<S: ReadWriteRPC> ReadWriteRPC for Vec<S> {
    fn rpc_read_from<T: Read>(reader: &mut T) -> Self {
        let len = reader.read_i32_be() as usize;
        let mut result = Vec::with_capacity(len);
        for _ in 0..len {
            result.push(S::rpc_read_from(reader))
        }
        result
    }

    fn rpc_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        writer.write_u32_be(self.len() as u32).unwrap();
        for item in self {
            item.rpc_write_to(writer).unwrap();
        }

        Ok(())
    }
}

impl<S: ReadWriteRPC> ReadWriteRPC for Option<S> {
    fn rpc_read_from<T: Read>(reader: &mut T) -> Self {
        let marker = reader.read_u8();
        match marker {
            0 => None,
            _ => Some(S::rpc_read_from(reader)),
        }
    }

    fn rpc_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        match &self {
            None => writer.write_u8(0),
            Some(value) => {
                writer.write_u8(1).unwrap();
                value.rpc_write_to(writer)
            }
        }
    }
}

impl ReadWriteRPC for String {
    fn rpc_read_from<T: Read>(reader: &mut T) -> Self {
        let vec: Vec<u8> = Vec::rpc_read_from(reader);
        String::from_utf8(vec).unwrap()
    }

    fn rpc_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        let utf_bytes = self.as_bytes();
        writer.write_u32_be(utf_bytes.len() as u32).unwrap();
        writer.write_all(utf_bytes)
    }
}

impl ReadWriteRPC for bool {
    fn rpc_read_from<T: Read>(reader: &mut T) -> Self {
        reader.read_u8() != 0
    }

    fn rpc_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        writer.write_u8(u8::from(*self))
    }
}

macro_rules! rw_int {
    ($($type:ty, $read_method:ident, $write_method:ident)*) => {
        $(
            impl ReadWriteRPC for $type {
                fn rpc_read_from<T: Read>(reader: &mut T) -> Self {
                    reader.$read_method()
                }

                fn rpc_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
                    writer.$write_method(*self)
                }
            }
        )*
    }
}

rw_int!(u8, read_u8, write_u8);
rw_int!(u16, read_u16_be, write_u16_be);
rw_int!(u32, read_u32_be, write_u32_be);
rw_int!(u64, read_u64_be, write_u64_be);
rw_int!(u128, read_u128_be, write_u128_be);

rw_int!(i8, read_i8, write_i8);
rw_int!(i16, read_i16_be, write_i16_be);
rw_int!(i32, read_i32_be, write_i32_be);
rw_int!(i64, read_i64_be, write_i64_be);
rw_int!(i128, read_i128_be, write_i128_be);

macro_rules! array_impls {
    ($($len:tt)+) => {
        $(
            impl ReadWriteRPC for [u8; $len] {
                fn rpc_read_from<T: Read>(reader: &mut T) -> Self {
                    let mut buf: [u8; $len] = [0; $len];
                    reader.read_exact(&mut buf).unwrap();
                    buf
                }

                fn rpc_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
                    let buf: [u8; $len] = [0; $len];
                    writer.write_all(&buf)
                }
            }
        )+
    }
}

array_impls!(
     1  2  3  4  5  6  7  8
     9 10 11 12 13 14 15 16
    17 18 19 20 21 22 23 24
    25 26 27 28 29 30 31 32
);
