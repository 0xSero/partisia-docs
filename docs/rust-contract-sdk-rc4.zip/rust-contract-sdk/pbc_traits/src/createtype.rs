use std::collections::{BTreeMap, BTreeSet};

/// This trait allows runtime type names.
pub trait CreateType: Sized {
    fn __ty_name() -> String;
    fn __ty_ordinal(w: &mut Vec<u8>);
}

macro_rules! impl_for_type {
    ($($type:ty, $val:literal)*) => {
        $(
            impl CreateType for $type {
                fn __ty_name() -> String {
                    format!("{}", quote!($type).to_string())
                }

                fn __ty_ordinal( w: &mut Vec<u8>) {
                    w.push($val)
                }
            }
        )*
    }
}

impl_for_type!(
    u8,     0x01
    u16,    0x02
    u32,    0x03
    u64,    0x04
    u128,   0x05
    i8,     0x06
    i16,    0x07
    i32,    0x08
    i64,    0x09
    i128,   0x0a
    String, 0x0b
    bool,   0x0c
);

impl<T: CreateType> CreateType for Vec<T> {
    fn __ty_name() -> String {
        let element_type = T::__ty_name();
        let result = format!("Vec<{}>", element_type);
        result
    }

    fn __ty_ordinal(w: &mut Vec<u8>) {
        w.push(0x0e);
        T::__ty_ordinal(w);
    }
}

impl<K: CreateType, V: CreateType> CreateType for BTreeMap<K, V> {
    fn __ty_name() -> String {
        let key_type = K::__ty_name();
        let value_type = V::__ty_name();
        format!("BTreeMap<{}, {}>", key_type, value_type)
    }

    fn __ty_ordinal(w: &mut Vec<u8>) {
        w.push(0x0f);
        K::__ty_ordinal(w);
        V::__ty_ordinal(w);
    }
}

impl<V: CreateType> CreateType for BTreeSet<V> {
    fn __ty_name() -> String {
        let value_type = V::__ty_name();
        let result = format!("BTreeSet<{}>", value_type);
        result
    }

    fn __ty_ordinal(w: &mut Vec<u8>) {
        w.push(0x10);
        V::__ty_ordinal(w);
    }
}

/// Implement CreateType for an array.
macro_rules! impl_for_array_type {
    ($($len:tt)+) => {
        $(
            impl CreateType for [u8; $len] {
                fn __ty_name() -> String {
                     format!("[u8; {}]", quote!($len).to_string())
                }

                fn __ty_ordinal(w: &mut Vec<u8>) {
                    w.push(0x11);
                    w.push($len);
                }
            }
        )+
    }
}

impl_for_array_type!(
     1  2  3  4  5  6  7  8
     9 10 11 12 13 14 15 16
    17 18 19 20 21 22 23 24
    25 26 27 28 29 30 31 32
);

#[cfg(test)]
mod test {
    use std::collections::{BTreeMap, BTreeSet};

    use crate::createtype::CreateType;

    fn assert_ty<T: CreateType>(name: &str, ord: &[u8]) {
        assert_eq!(T::__ty_name(), name);
        let mut vec = Vec::new();
        T::__ty_ordinal(&mut vec);
        assert_eq!(&vec, ord);
    }

    #[test]
    pub fn ty_names_and_ordinal() {
        assert_ty::<u8>("u8", &[0x01]);
        assert_ty::<u16>("u16", &[0x02]);
        assert_ty::<u32>("u32", &[0x03]);
        assert_ty::<u64>("u64", &[0x04]);
        assert_ty::<u128>("u128", &[0x05]);

        assert_ty::<i8>("i8", &[0x06]);
        assert_ty::<i16>("i16", &[0x07]);
        assert_ty::<i32>("i32", &[0x08]);
        assert_ty::<i64>("i64", &[0x09]);
        assert_ty::<i128>("i128", &[0x0a]);

        assert_ty::<String>("String", &[0x0b]);
        assert_ty::<bool>("bool", &[0x0c]);

        assert_ty::<Vec<u8>>("Vec<u8>", &[0x0e, 0x01]);
        assert_ty::<Vec<u16>>("Vec<u16>", &[0x0e, 0x02]);
        assert_ty::<Vec<u32>>("Vec<u32>", &[0x0e, 0x03]);
        assert_ty::<Vec<u64>>("Vec<u64>", &[0x0e, 0x04]);
        assert_ty::<Vec<u128>>("Vec<u128>", &[0x0e, 0x05]);

        assert_ty::<Vec<i8>>("Vec<i8>", &[0x0e, 0x06]);
        assert_ty::<Vec<i16>>("Vec<i16>", &[0x0e, 0x07]);
        assert_ty::<Vec<i32>>("Vec<i32>", &[0x0e, 0x08]);
        assert_ty::<Vec<i64>>("Vec<i64>", &[0x0e, 0x09]);
        assert_ty::<Vec<i128>>("Vec<i128>", &[0x0e, 0x0a]);

        assert_ty::<BTreeSet<i128>>("BTreeSet<i128>", &[0x10, 0x0a]);
        assert_ty::<BTreeMap<i128, u128>>("BTreeMap<i128, u128>", &[0x0f, 0x0a, 0x05]);

        assert_ty::<BTreeMap<Vec<BTreeMap<Vec<Vec<String>>, BTreeSet<BTreeMap<u32, u64>>>>, u128>>(
            "BTreeMap<Vec<BTreeMap<Vec<Vec<String>>, BTreeSet<BTreeMap<u32, u64>>>>, u128>",
            &[
                0x0f, 0x0e, 0x0f, 0x0e, 0x0e, 0x0b, 0x10, 0x0f, 0x03, 0x04, 0x05,
            ],
        );
    }

    // todo
}
