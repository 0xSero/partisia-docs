use std::collections::{BTreeMap, BTreeSet};
use std::io::{Read, Write};

use crate::readint::ReadInt;
use crate::writeint::WriteInt;
use crate::ReadWriteRPC;

pub trait ReadWriteState: Sized {
    fn state_read_from<T: Read>(reader: &mut T) -> Self;
    fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()>;
}

impl<S: ReadWriteState> ReadWriteState for Vec<S> {
    fn state_read_from<T: Read>(reader: &mut T) -> Self {
        let len = reader.read_i32_be() as usize;
        let mut result = Vec::with_capacity(len);
        for _ in 0..len {
            result.push(S::state_read_from(reader))
        }
        result
    }

    fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        writer.write_i32_be(self.len() as i32).unwrap();
        for item in self {
            item.state_write_to(writer).unwrap();
        }

        Ok(())
    }
}

impl<S: ReadWriteState> ReadWriteState for Option<S> {
    fn state_read_from<T: Read>(reader: &mut T) -> Self {
        let marker = reader.read_u8();
        match marker {
            0 => None,
            _ => Some(S::state_read_from(reader)),
        }
    }

    fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        match &self {
            None => writer.write_u8(0),
            Some(value) => {
                writer.write_u8(1).unwrap();
                value.state_write_to(writer)
            }
        }
    }
}

impl<K: ReadWriteState + Ord, V: ReadWriteState> ReadWriteState for BTreeMap<K, V> {
    fn state_read_from<T: Read>(reader: &mut T) -> Self {
        let mut result = BTreeMap::new();
        let len = reader.read_u32_be();

        for _ in 0..len {
            let key = K::state_read_from(reader);
            let value = V::state_read_from(reader);
            if result.insert(key, value).is_some() {
                panic!("Duplicate key added");
            }
        }

        result
    }

    fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        writer.write_u32_be(self.len() as u32)?;
        for (key, value) in self.iter() {
            key.state_write_to(writer)?;
            value.state_write_to(writer)?;
        }
        Ok(())
    }
}

impl<V: ReadWriteState + Ord + Copy> ReadWriteState for BTreeSet<V> {
    fn state_read_from<T: Read>(reader: &mut T) -> Self {
        let mut result = BTreeSet::new();
        let mut previous = None;

        let len = reader.read_u32_be();
        for _ in 0..len {
            let value = V::state_read_from(reader);
            let next = Some(value);
            if next <= previous {
                panic!("Unordered or duplicate key added");
            }

            result.insert(value);
            previous = next;
        }

        result
    }

    fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        writer.write_u32_be(self.len() as u32)?;
        for value in self.iter() {
            value.state_write_to(writer)?;
        }
        Ok(())
    }
}

/// A macro to derive `ReadWriteState` using the `ReadWriteRPC` implementation of read and write.
#[macro_export]
macro_rules! state_rw_from_rpc {
    ($($type:ty)*) => {
        $(
            impl ReadWriteState for $type {
                fn state_read_from<T: Read>(reader: &mut T) -> Self {
                   <$type as ReadWriteRPC>::rpc_read_from(reader)
                }

                fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
                    self.rpc_write_to(writer)
                }
            }
        )*
    }
}

state_rw_from_rpc!(
    String
    u8 u16 u32 u64
    i8 i16 i32 i64
    bool
);

macro_rules! array_impls {
    ($($len:tt)+) => {
        $(
            impl ReadWriteState for [u8; $len] {
                fn state_read_from<T: Read>(reader: &mut T) -> Self {
                    <[u8; $len]>::rpc_read_from(reader)
                }

                fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
                    self.rpc_write_to(writer)
                }
            }
        )+
    }
}

array_impls!(
     1  2  3  4  5  6  7  8
     9 10 11 12 13 14 15 16
    17 18 19 20 21 22 23 24
    25 26 27 28 29 30 31 32
);

#[cfg(test)]
mod test {
    use std::collections::BTreeMap;
    use std::io::Cursor;

    use crate::readwrite_state::ReadWriteState;

    #[test]
    pub fn read_write_btreemap() {
        let mut map: BTreeMap<u64, u64> = BTreeMap::new();
        map.insert(1u64, 2u64);
        map.insert(21u64, 42u64);

        let mut out: Vec<u8> = Vec::new();
        map.state_write_to(&mut out).unwrap();

        let mut cursor: Cursor<Vec<u8>> = Cursor::new(out.clone());
        let actual: BTreeMap<u64, u64> = BTreeMap::state_read_from(&mut cursor);

        assert_eq!(*actual.get(&1u64).unwrap(), 2u64);
        assert_eq!(*actual.get(&21u64).unwrap(), 42u64);
    }
}
