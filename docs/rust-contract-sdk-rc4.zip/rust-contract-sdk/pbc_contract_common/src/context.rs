use std::io::{Read, Write};

use crate::address::Address;
use crate::hash::Hash;
use pbc_traits::{ReadInt, ReadWriteRPC, ReadWriteState, WriteInt};

#[repr(C)]
#[derive(Eq, PartialEq, Debug)]
pub struct ContractContext {
    pub contract_address: Address,
    pub sender: Address,
    pub block_time: i64,
    pub block_production_time: i64,
    pub current_transaction: Hash,
    pub original_transaction: Hash,
}

impl ReadWriteState for ContractContext {
    fn state_read_from<T: Read>(reader: &mut T) -> Self {
        ContractContext {
            contract_address: Address::state_read_from(reader),
            sender: Address::state_read_from(reader),
            block_time: reader.read_i64_be(),
            block_production_time: reader.read_i64_be(),
            current_transaction: Hash::state_read_from(reader),
            original_transaction: Hash::state_read_from(reader),
        }
    }

    fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.contract_address.state_write_to(writer).unwrap();
        self.sender.state_write_to(writer).unwrap();
        writer.write_i64_be(self.block_time).unwrap();
        writer.write_i64_be(self.block_production_time).unwrap();
        self.current_transaction.state_write_to(writer).unwrap();
        self.original_transaction.state_write_to(writer)
    }
}

impl ReadWriteRPC for ContractContext {
    fn rpc_read_from<T: Read>(reader: &mut T) -> Self {
        ContractContext {
            contract_address: Address::rpc_read_from(reader),
            sender: Address::rpc_read_from(reader),
            block_time: reader.read_i64_be(),
            block_production_time: reader.read_i64_be(),
            current_transaction: Hash::rpc_read_from(reader),
            original_transaction: Hash::rpc_read_from(reader),
        }
    }

    fn rpc_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.contract_address.rpc_write_to(writer).unwrap();
        self.sender.rpc_write_to(writer).unwrap();
        writer.write_i64_be(self.block_time).unwrap();
        writer.write_i64_be(self.block_production_time).unwrap();
        self.current_transaction.rpc_write_to(writer).unwrap();
        self.original_transaction.rpc_write_to(writer)
    }
}

pub trait EventManager {}

impl ContractContext {
    pub fn create_event_manager(_callback: bool) -> Box<dyn EventManager> {
        todo!()
    }
}
