pub type Hash = [u8; 32];
