extern crate pbc_external;

use pbc_external::*;

pub fn raw_log(message: &str) {
    let string = message.to_string();
    let len = string.len();
    unsafe {
        log_external(string.as_ptr() as i64, len as i32);
    }
}

pub fn info(string: String) {
    raw_log(&string);
}
