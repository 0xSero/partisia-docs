use std::fs::File;
use std::io::{Read, Write};

use serde::ser::SerializeStruct;
use serde::{Serialize, Serializer};

use crate::abi::abi_serialize_slice;
use pbc_traits::WriteInt;
use read_write_state_derive::ReadWriteState;

use crate::abi::func::FnAbi;
use crate::abi::types::TypeAbi;

#[derive(PartialEq, Eq, ReadWriteState)]
pub struct ContractAbi {
    shortname_length: u8,
    types: Vec<TypeAbi>,
    init: FnAbi,
    actions: Vec<FnAbi>,
    state: Vec<u8>,
}

impl ContractAbi {
    pub fn new(init: FnAbi, state: Vec<u8>) -> Self {
        let actions = Vec::new();
        let types = Vec::new();
        ContractAbi {
            shortname_length: 4,
            init,
            actions,
            state,
            types,
        }
    }

    pub fn actions(&mut self, actions: Vec<FnAbi>) {
        self.actions = actions;
    }

    pub fn types(&mut self, types: Vec<TypeAbi>) {
        self.types = types;
    }

    pub fn as_json(&self, path: String) -> std::io::Result<()> {
        let mut file = File::create(path)?;
        let content = serde_json::to_string_pretty(&self).unwrap();
        file.write_all(content.as_bytes())?;
        Ok(())
    }

    /// Serialize this struct according to the ABI specification.
    pub fn serialize_abi<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        writer.write_u8(self.shortname_length)?;
        abi_serialize_slice(&self.types, TypeAbi::serialize_abi, writer)?;
        self.init.serialize_abi(writer)?;
        abi_serialize_slice(&self.actions, FnAbi::serialize_abi, writer)?;
        abi_serialize_slice(&self.state, |x, w| w.write_u8(*x), writer)
    }
}

impl Serialize for ContractAbi {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let mut contract_abi = serializer.serialize_struct("ContractAbi", 3).unwrap();
        contract_abi.serialize_field("shortname_length", &self.shortname_length)?;
        contract_abi.serialize_field("types", &self.types)?;
        contract_abi.serialize_field("init", &self.init)?;
        contract_abi.serialize_field("actions", &self.actions)?;
        contract_abi.serialize_field("state", &self.state)?;
        contract_abi.end()
    }
}
