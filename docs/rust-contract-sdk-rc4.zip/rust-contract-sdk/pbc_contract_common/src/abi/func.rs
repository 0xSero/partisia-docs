extern crate sha2;

use std::collections::BTreeMap;
use std::convert::TryInto;
use std::io::{Read, Write};

use crate::abi::abi_serialize_slice;
use pbc_traits::{CreateType, ReadInt, ReadWriteRPC, ReadWriteState, WriteInt};
use serde::ser::SerializeStruct;
use serde::{Serialize, Serializer};
use sha2::{Digest, Sha256};

use crate::abi::argument::ArgumentAbi;
use crate::TypeKey;

#[derive(PartialEq, Eq)]
pub struct FnAbi {
    name: String,
    shortname: u32,
    args: Vec<ArgumentAbi>,
}

impl FnAbi {
    pub fn new(name: String) -> Self {
        let args = Vec::new();
        let shortname = name_to_shortname(&name);
        FnAbi {
            name,
            args,
            shortname,
        }
    }

    pub fn argument<T: CreateType>(&mut self, name: String, lut: &BTreeMap<TypeKey, u8>) {
        self.args.push(ArgumentAbi::new::<T>(name, lut));
    }

    pub fn serialize_abi<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.name.rpc_write_to(writer)?;
        abi_serialize_slice(&self.args, ArgumentAbi::serialize_abi, writer)
    }
}

impl ReadWriteState for FnAbi {
    fn state_read_from<T: Read>(reader: &mut T) -> Self {
        let mut fn_abi = FnAbi::new(String::state_read_from(reader));
        let field_count = reader.read_u32_be();
        for _ in 0..field_count {
            fn_abi.args.push(ArgumentAbi::state_read_from(reader));
        }
        fn_abi
    }

    fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.name.state_write_to(writer)?;
        writer.write_u32_be(self.args.len() as u32)?;
        for arg in self.args.iter() {
            arg.state_write_to(writer)?;
        }
        Ok(())
    }
}

impl Serialize for FnAbi {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let mut fn_abi = serializer.serialize_struct("FnAbi", 3).unwrap();
        fn_abi.serialize_field("name", &self.name)?;

        let short_name = format!("{:X}", self.shortname);
        fn_abi.serialize_field("shortname", &short_name)?;
        fn_abi.serialize_field("arguments", &self.args)?;
        fn_abi.end()
    }
}

pub fn name_to_shortname(raw_name: &str) -> u32 {
    let mut digest = Sha256::new();
    Digest::update(&mut digest, raw_name.as_bytes());
    let output = digest.finalize();
    let first_four = output.chunks(4).next().unwrap();
    u32::from_be_bytes(first_four.try_into().unwrap())
}

pub fn name_to_shortname_as_string(raw_name: &str) -> String {
    format!("{:x}", name_to_shortname(raw_name))
}

#[cfg(test)]
mod test {
    use crate::abi::func::name_to_shortname;

    #[test]
    pub fn test() {
        println!("{}", name_to_shortname("vote"))
    }
}
