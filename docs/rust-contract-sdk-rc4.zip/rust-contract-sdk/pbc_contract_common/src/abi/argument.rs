use std::collections::BTreeMap;
use std::io::{Read, Write};

use serde::ser::SerializeStruct;
use serde::{Serialize, Serializer};

use pbc_traits::{CreateType, ReadWriteRPC, WriteInt};
use read_write_state_derive::ReadWriteState;

use crate::abi::TypeKey;

#[derive(PartialEq, Eq, ReadWriteState)]
pub struct ArgumentAbi {
    name: String,
    type_ordinals: Vec<u8>,
    type_index: Option<u8>,
}

impl ArgumentAbi {
    pub fn new<T: CreateType>(name: String, lut: &BTreeMap<TypeKey, u8>) -> Self {
        let mut type_ordinals = Vec::new();
        T::__ty_ordinal(&mut type_ordinals);

        let type_key = TypeKey::create::<T>();
        let type_index = lut.get(&type_key).copied();

        ArgumentAbi {
            name,
            type_ordinals,
            type_index,
        }
    }

    pub fn serialize_abi<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.name.rpc_write_to(writer)?;

        for ord in self.type_ordinals.iter() {
            writer.write_u8(*ord)?;
        }

        if let Some(idx) = self.type_index {
            writer.write_u8(idx)?;
        }

        Ok(())
    }
}

impl Serialize for ArgumentAbi {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let mut arg_abi = serializer.serialize_struct("ArgumentAbi", 2).unwrap();
        arg_abi.serialize_field("name", &self.name)?;
        arg_abi.serialize_field("type", &self.type_ordinals)?;
        // TODO
        arg_abi.end()
    }
}
