use std::io::{Read, Write};

use serde_derive::Serialize;

use crate::abi::abi_serialize_slice;
use pbc_traits::{CreateType, ReadWriteRPC};
use read_write_state_derive::ReadWriteState;

use crate::abi::field::FieldAbi;
use crate::TypeKey;

#[derive(PartialEq, Debug, Eq, Serialize, ReadWriteState)]
pub struct TypeAbi {
    pub name: String,
    pub type_key: TypeKey,
    pub fields: Vec<FieldAbi>,
}

impl TypeAbi {
    pub fn new<T: CreateType>(name: String) -> Self {
        let fields = Vec::new();
        let mut type_ordinals = Vec::new();
        T::__ty_ordinal(&mut type_ordinals);
        TypeAbi {
            name,
            type_key: TypeKey::create::<T>(),
            fields,
        }
    }

    pub fn field(&mut self, field: FieldAbi) {
        self.fields.push(field);
    }

    pub fn serialize_abi<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.name.rpc_write_to(writer)?;
        abi_serialize_slice(&self.fields, FieldAbi::serialize_abi, writer)
    }
}
