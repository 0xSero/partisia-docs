use std::io::Read;
use std::io::Write;

use serde::{Serialize, Serializer};

use pbc_traits::{CreateType, WriteInt};
use read_write_rpc_derive::ReadWriteRPC;
use read_write_state_derive::ReadWriteState;

mod argument;
pub mod contract;
pub mod field;
pub mod func;
pub mod types;

/// Create a header for the given version
pub fn abi_header_bytes(version: u16) -> [u8; 8] {
    let mut bytes = [0u8; 8];
    for (i, byte) in "PBCABI".as_bytes().iter().enumerate() {
        bytes[i] = *byte;
    }

    let version_bytes = u16::to_be_bytes(version);
    bytes[6] = version_bytes[0];
    bytes[7] = version_bytes[1];

    bytes
}

/// Serialize this struct according to the ABI specification.
///
/// * `slice` - the slice of T's to write to the stream
/// * `write_elem` - a function that takes a &T and writes it to the specified writer
/// * `writer` - the writer
///
pub fn abi_serialize_slice<T, W: Write>(
    slice: &[T],
    write_elem: fn(&T, &mut W) -> std::io::Result<()>,
    writer: &mut W,
) -> std::io::Result<()> {
    writer.write_u32_be(slice.len() as u32)?;
    for t in slice.iter() {
        write_elem(t, writer)?;
    }
    Ok(())
}

#[derive(ReadWriteState, ReadWriteRPC, Eq, PartialEq, Debug, PartialOrd, Ord, Clone)]
pub struct TypeKey {
    name: String,
    pub ordinals: Vec<u8>,
}

impl TypeKey {
    pub fn create<T: CreateType>() -> TypeKey {
        let name = T::__ty_name();
        let mut ordinals = Vec::new();
        T::__ty_ordinal(&mut ordinals);

        TypeKey { name, ordinals }
    }
}

impl Serialize for TypeKey {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        serializer.serialize_u8(0)
    }
}

#[cfg(test)]
mod test {
    use crate::abi::abi_header_bytes;

    #[test]
    pub fn assert_version() {
        let bytes = abi_header_bytes(42);
        assert_eq!(bytes, [80, 66, 67, 65, 66, 73, 0, 42]);
        let i = u8::from_be_bytes([1; 1]);
        println!("{}", i);
    }
}
