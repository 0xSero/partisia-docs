use std::io::{Read, Write};

use serde_derive::Serialize;

use pbc_traits::*;

#[repr(C)]
#[derive(Eq, PartialEq, Debug, Clone, Ord, PartialOrd, Copy, Serialize)]
pub enum Address {
    Account(Identifier),
    SystemContract(Identifier),
    PublicContract(Identifier),
    ZkContract(Identifier),
}

type Identifier = [u8; 20];

impl ReadWriteRPC for Address {
    fn rpc_read_from<T: Read + ReadInt>(reader: &mut T) -> Self {
        let address_type = reader.read_u8();
        let mut content = [0u8; 20];
        reader.read_exact(&mut content).unwrap();

        match address_type {
            0 => Address::Account(content),
            1 => Address::SystemContract(content),
            2 => Address::PublicContract(content),
            3 => Address::ZkContract(content),
            n => {
                panic!("Unrecognized address type {}", n)
            }
        }
    }

    fn rpc_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        match self {
            Address::Account(content) => {
                writer.write_u8(0)?;
                writer.write_all(content)
            }
            Address::SystemContract(content) => {
                writer.write_u8(1)?;
                writer.write_all(content)
            }
            Address::PublicContract(content) => {
                writer.write_u8(2)?;
                writer.write_all(content)
            }
            Address::ZkContract(content) => {
                writer.write_u8(3)?;
                writer.write_all(content)
            }
        }
    }
}

impl ReadWriteState for Address {
    fn state_read_from<T: Read + ReadInt>(reader: &mut T) -> Self {
        <Address as ReadWriteRPC>::rpc_read_from(reader)
    }

    fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.rpc_write_to(writer)
    }
}

impl CreateType for Address {
    fn __ty_name() -> String {
        "Address".to_string()
    }

    fn __ty_ordinal(w: &mut Vec<u8>) {
        w.push(0x0d)
    }
}
