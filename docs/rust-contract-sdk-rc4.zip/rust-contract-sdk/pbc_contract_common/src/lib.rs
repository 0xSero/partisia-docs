extern crate quote;

use std::collections::BTreeMap;
use std::io::Read;
use std::ptr;

use pbc_traits::ReadWriteState;

use crate::abi::TypeKey;

pub mod abi;
pub mod address;
pub mod base;
pub mod context;
pub mod hash;

#[allow(clippy::not_unsafe_ptr_arg_deref)]
pub fn abi_to_ptr<T: ReadWriteState>(abi: T, dest_ptr: *mut u8) -> u32 {
    let mut mem: Vec<u8> = Vec::new();
    abi.state_write_to(&mut mem).unwrap();
    let length = mem.len();

    unsafe {
        ptr::copy(mem.as_ptr(), dest_ptr, length);
    }

    length as u32
}

struct RawRead {
    base_pointer: *mut u8,
}

impl Read for RawRead {
    fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
        unsafe {
            for buf_item in buf.iter_mut() {
                *buf_item = std::ptr::read(self.base_pointer);
                self.base_pointer = self.base_pointer.add(1);
            }
        }

        Ok(buf.len())
    }
}

/// TODO can be generic
pub fn read_lut_from_ptr(ptr: *mut u8) -> BTreeMap<TypeKey, u8> {
    let mut read = RawRead { base_pointer: ptr };
    ReadWriteState::state_read_from(&mut read)
}
