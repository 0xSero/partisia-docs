extern crate derive_commons;
extern crate proc_macro;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro::TokenStream;

use syn::__private::TokenStream2;
use syn::{Data, Fields, Ident};

#[proc_macro_derive(CreateType)]
pub fn create_type(input: TokenStream) -> TokenStream {
    // Parse the string representation
    let ast = syn::parse(input).unwrap();

    // Build the impl
    let gen = impl_create_type(&ast);

    // Return the generated impl
    gen.into()
}

fn impl_create_type(ast: &syn::DeriveInput) -> proc_macro2::TokenStream {
    let name = &ast.ident;
    let (field_names, field_types) = data_to_field_types(&ast.data);
    let string_name = name.to_string();

    let lowercase_name = name.to_string().to_lowercase();
    let lowercase_ident = format_ident!("{}", &name.to_string().to_lowercase());
    let mut implementation = quote! {
        impl pbc_traits::CreateType for #name {
            fn __ty_name() -> String {
                let #lowercase_ident =  format!("{}", #string_name);
                #(
                    let #field_names = <#field_types as pbc_traits::CreateType>::__ty_name();
                )*
                #lowercase_ident
            }

            fn __ty_ordinal(w: &mut Vec<u8>) {
                w.push(0x00);
            }
        }
    };

    let fields_string_names: Vec<String> = field_names
        .iter()
        .map(|name| -> String { name.to_string().to_lowercase() })
        .collect();
    let create_func_ident = format_ident!("create_{}", lowercase_name);

    let create_type = quote! {
        fn #create_func_ident(lut_ptr: *mut u8) -> pbc_contract_common::abi::types::TypeAbi {
            let mut type_abi = pbc_contract_common::abi::types::TypeAbi::new::<#name>(format!("{}", #string_name));
            let lut = pbc_contract_common::read_lut_from_ptr(lut_ptr);
            #(
                let #field_names = pbc_contract_common::abi::field::FieldAbi::new::<#field_types>(#fields_string_names.to_string(), &lut);
                type_abi.field(#field_names);
            )*

            type_abi
        }
    };

    let var_type = format_ident!("v_{}_abi", lowercase_name);
    let func_name = format_ident!("abi_type_{}_to_ptr", lowercase_name);
    let to_ptr_func = quote! {
        #[no_mangle]
        pub extern "C" fn #func_name(ptr: *mut u8, lut_ptr: *mut u8) -> u32 {
            let #var_type = #create_func_ident(lut_ptr);
            pbc_contract_common::abi_to_ptr(#var_type, ptr)
        }
    };

    implementation.extend(create_type);
    implementation.extend(to_ptr_func);
    implementation
}

fn data_to_field_types(data: &Data) -> (Vec<Ident>, Vec<TokenStream2>) {
    match *data {
        Data::Struct(ref data) => match data.fields {
            Fields::Named(ref fields) => {
                let names: Vec<Ident> = fields
                    .named
                    .iter()
                    .map(derive_commons::field_to_name)
                    .collect();
                let types: Vec<TokenStream2> = fields
                    .named
                    .iter()
                    .map(derive_commons::field_to_type)
                    .collect();
                (names, types)
            }
            _ => unimplemented!(),
        },
        _ => unimplemented!(),
    }
}
