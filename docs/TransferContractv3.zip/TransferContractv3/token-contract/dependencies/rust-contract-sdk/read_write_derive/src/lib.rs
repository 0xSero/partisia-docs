extern crate proc_macro;

#[macro_use]
extern crate quote;
extern crate syn;
use proc_macro::TokenStream;
use syn::{Data, Field, Fields, Ident, Type};

#[proc_macro_derive(ReadWrite)]
pub fn read_write(input: TokenStream) -> TokenStream {
    // Parse the string representation
    let ast = syn::parse(input).unwrap();

    // Build the impl
    let gen = impl_read_write(&ast);

    // Return the generated impl
    gen.into()
}

fn impl_read_write(ast: &syn::DeriveInput) -> proc_macro2::TokenStream {
    let name = &ast.ident;
    let fieldnames = fields_to_names(&ast.data);
    let (readlines, writelines) = make_read_and_write_lines(&ast.data);

    let implementation = quote! {
        impl ReadWrite for #name {
            fn read_from<T: Read>(reader: &mut T) -> Self {
                #readlines
                #name {
                    #(#fieldnames),*
                }
            }

            fn write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
                #writelines
            }
        }
    };
    implementation
}

fn make_read_and_write_lines(data: &Data) -> (proc_macro2::TokenStream, proc_macro2::TokenStream) {
    match *data {
        Data::Struct(ref data) => match data.fields {
            Fields::Named(ref fields) => {
                let names: Vec<Ident> = fields.named.iter().map(field_to_name).collect();
                let types: Vec<Ident> = fields.named.iter().map(field_to_type).collect();
                let readlines = quote! {
                    #(
                        let #names =  #types::read_from(reader);
                    )*
                };
                let writelines = quote! {
                    #(
                        #types::write_to(&self.#names, writer)?;
                    )*
                    return Ok(());
                };
                (readlines, writelines)
            }
            _ => {
                unimplemented!()
            }
        },
        _ => unimplemented!(),
    }
}

fn field_to_name(field: &Field) -> Ident {
    field.ident.clone().unwrap()
}

fn field_to_type(field: &Field) -> Ident {
    let ty: Ident = match &field.ty {
        Type::Path(path) => path.path.segments.last().unwrap().clone().ident,
        _ => unimplemented!(),
    };
    ty
}

fn fields_to_names(data: &Data) -> Vec<Ident> {
    let list_of_names: Vec<Ident> = match *data {
        Data::Struct(ref data) => match data.fields {
            Fields::Named(ref fields) => fields.named.iter().map(field_to_name).collect(),
            _ => unimplemented!(),
        },
        _ => unimplemented!(),
    };

    list_of_names
}
