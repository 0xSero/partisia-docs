extern crate reflection;
#[macro_use]
extern crate reflection_derive;

use reflection::Reflection;

use pbc_contract_codegen::state;

#[state]
pub struct TestState {
    _counter: u64,
    _coin: ExternalCoin,
    _balance: u64,
    _lock: bool,
}

#[derive(PartialEq, Eq, Clone, Debug, Reflection)]
struct ExternalCoin {
    _symbol: [u8; 16],
    _price_per_1k_gas: u64,
}
