extern crate reflection;
#[macro_use]
extern crate reflection_derive;

use std::io::{Read, Write};

use reflection::Reflection;

use pbc_contract_codegen::{init, state};
use pbc_contract_common::context::ContractContext;
use pbc_contract_common::serialization::{ReadInt, ReadWrite};

#[state]
struct State {
    value: u64,
}

// TODO: [tth]: Can we get the #[state] attribute to derive(ReadWrite)?
impl ReadWrite for State {
    fn read_from<T: Read>(_reader: &mut T) -> Self {
        todo!()
    }

    fn write_to<T: Write>(&self, _writer: &mut T) -> std::io::Result<()> {
        todo!()
    }
}

#[init]
fn _initialize_contract_state(_ctx: ContractContext, value: u64, _vec: Vec<u8>) -> State {
    State { value }
}
