extern crate reflection;
#[macro_use]
extern crate reflection_derive;

use std::ptr;

use reflection::Member;
use serde_json::value::Value::Object;
use serde_json::{Map, Value};
use trees::Node;

use crate::serialization::ReadWrite;

pub mod abi;
pub mod address;
pub mod base;
pub mod context;
pub mod hash;
pub mod serialization;
mod typechecker;

pub fn schema_as_json(node: &Node<Member>) -> String {
    let result_map = tree_to_map(node);
    format!("{}", Object(result_map))
}

pub fn fn_abi_to_ptr<T: ReadWrite>(abi: T, dest_ptr: *mut u8) -> u32 {
    let mut mem: Vec<u8> = Vec::new();
    abi.write_to(&mut mem).unwrap();
    let length = mem.len();

    unsafe {
        ptr::copy(mem.as_ptr(), dest_ptr, length);
    }

    length as u32
}

fn tree_to_map(node: &Node<Member>) -> Map<String, Value> {
    let mut result = serde_json::to_value(node.data()).unwrap();
    if !node.has_no_child() {
        let mut children: Vec<Value> = Vec::new();
        node.iter()
            .for_each(|child| children.push(Value::Object(tree_to_map(child))));
        result
            .as_object_mut()
            .unwrap()
            .insert("children".to_string(), Value::Array(children));
    }
    result.as_object().unwrap().clone()
}
