use crate::abi::func::FnAbi;
use crate::abi::types::TypeAbi;
use crate::serialization::ReadWrite;
use read_write_derive::ReadWrite;
use serde::ser::SerializeStruct;
use serde::{Serialize, Serializer};
use std::fs::File;
use std::io::{Read, Write};

#[derive(PartialEq, Eq, ReadWrite)]
pub struct ContractAbi {
    init: FnAbi,
    actions: Vec<FnAbi>,
    types: Vec<TypeAbi>,
    state: String,
}

impl ContractAbi {
    pub fn new(init: FnAbi, state: String) -> Self {
        let actions = Vec::new();
        let types = Vec::new();
        ContractAbi {
            init,
            actions,
            state,
            types,
        }
    }

    pub fn action(&mut self, action: FnAbi) -> &mut Self {
        self.actions.push(action);
        self
    }

    pub fn ty(&mut self, type_abi: TypeAbi) -> &mut Self {
        self.types.push(type_abi);
        self
    }

    pub fn actions(&mut self, actions: Vec<FnAbi>) -> &mut Self {
        self.actions = actions;
        self
    }

    pub fn types(&mut self, types: Vec<TypeAbi>) -> &mut Self {
        self.types = types;
        self
    }

    pub fn as_json(&self, path: String) -> std::io::Result<()> {
        let mut file = File::create(path)?;
        let content = serde_json::to_string_pretty(&self).unwrap();
        file.write_all(content.as_bytes())?;
        Ok(())
    }
}

impl Serialize for ContractAbi {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let mut contract_abi = serializer.serialize_struct("ContractAbi", 3).unwrap();
        contract_abi.serialize_field("shortname_length", &4)?;
        contract_abi.serialize_field("types", &self.types)?;
        contract_abi.serialize_field("init", &self.init)?;
        contract_abi.serialize_field("actions", &self.actions)?;
        contract_abi.serialize_field("state", &self.state)?;
        contract_abi.end()
    }
}

#[cfg(test)]
mod test {
    use crate::abi::contract::ContractAbi;
    use crate::abi::field::FieldAbi;
    use crate::abi::func::FnAbi;
    use crate::abi::types::TypeAbi;
    use crate::serialization::ReadWrite;
    use std::fs;

    use file_diff::diff_files;
    use std::fs::File;
    use std::io::Cursor;

    #[test]
    fn write_and_read_contract() {
        let fn_name: String = String::from("function_name1");
        let mut function = FnAbi::new(fn_name);
        let arg_name = String::from("arg1");
        let arg_ty = String::from("u8");
        function.argument(arg_name, arg_ty);

        let fn_name2: String = String::from("function_name2");
        let mut function2 = FnAbi::new(fn_name2);
        let arg_name2 = String::from("arg1");
        let arg_ty2 = String::from("u8");
        function2.argument(arg_name2, arg_ty2);

        let fn_name3: String = String::from("function_name3");
        let function3 = FnAbi::new(fn_name3);

        let fn_name4: String = String::from("function_name4");
        let function4 = FnAbi::new(fn_name4);

        let fn_name5: String = String::from("function_name5");
        let function5 = FnAbi::new(fn_name5);

        let state: String = String::from("state");

        let mut contract = ContractAbi::new(function, state);
        contract.action(function2);
        contract.action(function3);
        contract.action(function4);
        contract.action(function5);

        let mut buff = Cursor::new(Vec::new());
        contract.write_to(&mut buff).unwrap();
        let mut reader = Cursor::new(buff.into_inner());

        let contract_read = ContractAbi::read_from(&mut reader);

        assert!(contract == contract_read)
    }

    #[test]
    fn json_should_match() {
        fs::create_dir_all("testoutput/").unwrap();

        let fn_name: String = String::from("init");
        let mut init = FnAbi::new(fn_name);
        let arg1 = String::from("arg1");
        let arg_ty1 = String::from("u64");
        init.argument(arg1, arg_ty1);

        //Mint function
        let fn_name2: String = String::from("mint");
        let mut mint_function = FnAbi::new(fn_name2);
        let arg_name2 = String::from("amount");
        let arg_ty2 = String::from("u64");
        mint_function.argument(arg_name2, arg_ty2);

        //Transfer function
        let fn_name3: String = String::from("transfer");
        let arg_dest = String::from("dest");
        let arg_ty3 = String::from("Address");
        let arg_amount = String::from("amount");
        let arg_ty4 = String::from("u64");
        let mut transfer_function = FnAbi::new(fn_name3);
        transfer_function.argument(arg_dest, arg_ty3);
        transfer_function.argument(arg_amount, arg_ty4);

        // Balance type
        let address = FieldAbi::new(String::from("address"), String::from("Address"));
        let value_field = FieldAbi::new(String::from("value"), String::from("u64"));
        let mut balance = TypeAbi::new(String::from("Balance"));
        balance.field(address);
        balance.field(value_field);

        // TokenContractState type
        let symbol_field = FieldAbi::new(String::from("symbol"), String::from("[u8, 16]"));
        let total_supply_field = FieldAbi::new(String::from("total_supply"), String::from("u64"));
        let balances = FieldAbi::new(
            String::from("balances"),
            String::from("BTreeMap<Address, u64>"),
        );
        let name = String::from("TokenContractState");
        let mut token_contract_state: TypeAbi = TypeAbi::new(name);
        token_contract_state.field(symbol_field);
        token_contract_state.field(total_supply_field);
        token_contract_state.field(balances);

        let state: String = String::from("TokenContractState");

        // Contract
        let mut contract = ContractAbi::new(init, state);
        contract.action(mint_function);
        contract.action(transfer_function);
        contract.ty(token_contract_state);
        contract.ty(balance);

        let path = String::from("testoutput/json-should-match.json");
        let resultpath = String::from("testdata/json-should-match.json");
        let _result_json = contract.as_json(path.clone()).unwrap();

        let mut file1 = match File::open(path) {
            Ok(f) => f,
            Err(e) => panic!("{}", e),
        };
        let mut file2 = match File::open(resultpath) {
            Ok(f) => f,
            Err(e) => panic!("{}", e),
        };

        assert!(diff_files(&mut file1, &mut file2));
    }
}
