extern crate sha2;

use std::convert::TryInto;
use std::io::{Read, Write};

use serde::ser::SerializeStruct;
use serde::{Serialize, Serializer};
use sha2::{Digest, Sha256};

use crate::abi::argument::ArgumentAbi;
use crate::serialization::ReadWrite;
use read_write_derive::ReadWrite;

#[derive(PartialEq, Eq, ReadWrite)]
pub struct FnAbi {
    name: String,
    shortname: u32,
    args: Vec<ArgumentAbi>,
}

impl FnAbi {
    pub fn new(name: String) -> Self {
        let args = Vec::new();
        let shortname = hash_identifier(&name);
        FnAbi {
            name,
            args,
            shortname,
        }
    }

    pub fn argument(&mut self, name: String, ty: String) -> &mut Self {
        self.args.push(ArgumentAbi::new(name, ty));
        self
    }
}

impl Serialize for FnAbi {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let mut fn_abi = serializer.serialize_struct("FnAbi", 3).unwrap();
        fn_abi.serialize_field("name", &self.name)?;

        let short_name = format!("{:X}", self.shortname);
        fn_abi.serialize_field("shortname", &short_name)?;
        fn_abi.serialize_field("arguments", &self.args)?;
        fn_abi.end()
    }
}

pub fn hash_identifier(raw_name: &str) -> u32 {
    let mut digest = Sha256::new();
    Digest::update(&mut digest, raw_name.as_bytes());
    let output = digest.finalize();
    let last_four_bytes = output.chunks(4).next().unwrap();
    u32::from_le_bytes(last_four_bytes.try_into().unwrap())
}

#[cfg(test)]
mod test {
    use std::io::Cursor;

    use crate::abi::func::FnAbi;
    use crate::serialization::ReadWrite;

    #[test]
    fn write_and_read_fnabi() {
        let fn_name = String::from("fn1");
        let mut function = FnAbi::new(fn_name);

        let name = String::from("arg1");
        let ty = String::from("u8");
        function.argument(name, ty);

        let mut buff = Cursor::new(Vec::new());
        function.write_to(&mut buff).unwrap();

        let mut reader = Cursor::new(buff.into_inner());
        let fn_read = FnAbi::read_from(&mut reader);

        assert!(fn_read == function)
    }
}
