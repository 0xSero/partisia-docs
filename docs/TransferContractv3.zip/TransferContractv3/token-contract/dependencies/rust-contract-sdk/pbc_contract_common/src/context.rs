use std::io::{Read, Write};

use reflection::Reflection;

use crate::address::Address;
use crate::hash::Hash;
use crate::serialization::{ReadInt, ReadWrite, WriteInt};

#[repr(C)]
#[derive(Eq, PartialEq, Debug, Reflection)]
pub struct ContractContext {
    pub contract_address: Address,
    pub sender: Address,
    pub block_time: i64,
    pub block_production_time: i64,
    pub current_transaction: Hash,
    pub original_transaction: Hash,
}

impl ReadWrite for ContractContext {
    fn read_from<T: Read>(reader: &mut T) -> Self {
        ContractContext {
            contract_address: Address::read_from(reader),
            sender: Address::read_from(reader),
            block_time: reader.read_i64_be(),
            block_production_time: reader.read_i64_be(),
            current_transaction: Hash::read_from(reader),
            original_transaction: Hash::read_from(reader),
        }
    }

    fn write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.contract_address.write_to(writer).unwrap();
        self.sender.write_to(writer).unwrap();
        writer.write_i64_be(self.block_time).unwrap();
        writer.write_i64_be(self.block_production_time).unwrap();
        self.current_transaction.write_to(writer).unwrap();
        self.original_transaction.write_to(writer)
    }
}

pub trait EventManager {}

impl ContractContext {
    pub fn create_event_manager(_callback: bool) -> Box<dyn EventManager> {
        todo!()
    }
}
