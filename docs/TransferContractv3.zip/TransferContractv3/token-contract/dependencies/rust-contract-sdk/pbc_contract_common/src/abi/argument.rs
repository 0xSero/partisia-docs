use crate::serialization::ReadWrite;
use read_write_derive::ReadWrite;
use serde::ser::SerializeStruct;
use serde::{Serialize, Serializer};
use std::io::{Read, Write};

#[derive(PartialEq, Eq, ReadWrite)]
pub struct ArgumentAbi {
    name: String,
    ty: String, // Type name, lookup in "types"
}

impl ArgumentAbi {
    pub fn new(name: String, ty: String) -> Self {
        ArgumentAbi { name, ty }
    }
}

impl Serialize for ArgumentAbi {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let mut arg_abi = serializer.serialize_struct("ArgumentAbi", 2).unwrap();
        arg_abi.serialize_field("name", &self.name)?;
        arg_abi.serialize_field("type", &self.ty)?;
        arg_abi.end()
    }
}

#[cfg(test)]
mod test {
    use crate::abi::argument::ArgumentAbi;
    use crate::serialization::ReadWrite;
    use crate::typechecker::Typechecker;

    use std::io::Cursor;

    #[test]
    fn write_and_read_argument_abi() {
        let name = String::from("arg1");
        let ty = String::from("u8");
        let argument = ArgumentAbi { name, ty };
        let mut buff = Cursor::new(Vec::new());
        argument.write_to(&mut buff).unwrap();
        let mut reader = Cursor::new(buff.into_inner());

        let argument_read = ArgumentAbi::read_from(&mut reader);
        assert!(argument == argument_read)
    }

    #[test]
    fn write_and_read_each_type() {
        let typ = Typechecker::new();
        let mut args: Vec<ArgumentAbi> = Vec::new();
        let mut args_read: Vec<ArgumentAbi> = Vec::new();
        for i in &typ.legal_types {
            args.push(ArgumentAbi {
                name: String::from("name"),
                ty: String::from(i),
            })
        }
        let mut buff = Cursor::new(Vec::new());
        for i in &args {
            i.write_to(&mut buff).unwrap();
        }
        let number_of_types = typ.legal_types.len();
        let mut reader = Cursor::new(buff.into_inner());
        for _i in 0_usize..number_of_types {
            args_read.push(ArgumentAbi::read_from(&mut reader))
        }

        for _i in 0_usize..number_of_types {
            assert!(args_read[_i] == args[_i])
        }
    }
}
