#[allow(dead_code)]
pub struct Typechecker {
    pub(crate) legal_types: Vec<String>,
}
#[allow(dead_code)]
impl Typechecker {
    pub fn new() -> Typechecker {
        let mut vec: Vec<String> = vec![
            String::from("CUSTOM_STRUCT"),
            String::from("u8"),
            String::from("u16"),
            String::from("u32"),
            String::from("u64"),
            String::from("u128"),
            String::from("i8"),
            String::from("i16"),
            String::from("i32"),
            String::from("i64"),
            String::from("i128"),
            String::from("Vec<T>"),
            String::from("BTreeMap<S, T>"),
            String::from("BTreeSet"),
        ];
        for i in 1..=32 {
            vec.push(format!("[u8; {}]", i))
        }

        Typechecker { legal_types: vec }
    }

    pub fn get_type(&self, number: u8) -> Option<&String> {
        self.legal_types.get(number as usize)
    }

    pub fn get_int(&self, ty: &str) -> Option<u8> {
        let int = self.legal_types.iter().position(|x| x.eq(ty));
        match int {
            None => panic!("Type does not exist"),
            Some(val) => Some(val as u8),
        }
    }
}

#[cfg(test)]
mod test {
    use crate::typechecker::Typechecker;

    #[test]
    fn test_map_equality() {
        let types: Typechecker = Typechecker::new();
        for i in 1..types.legal_types.len() {
            let typ = types.get_type(i as u8);
            let number = types.get_int(&String::from(typ.unwrap()));
            assert_eq!(number.unwrap(), i as u8);
        }
    }

    #[test]
    #[should_panic(expected = "Type does not exist")]
    fn test_wrong_types() {
        let types: Typechecker = Typechecker::new();
        let wrong_type = String::from("Double");
        let _int = types.get_int(&wrong_type);
    }
}
