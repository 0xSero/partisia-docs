use crate::abi::field::FieldAbi;
use crate::serialization::ReadWrite;

use read_write_derive::ReadWrite;
use serde::Serialize;
use std::io::{Read, Write};

#[derive(PartialEq, Eq, Serialize, ReadWrite)]
pub struct TypeAbi {
    name: String,
    fields: Vec<FieldAbi>,
}

impl TypeAbi {
    pub fn new(name: String) -> Self {
        let fields = Vec::new();
        TypeAbi { name, fields }
    }

    pub fn field(&mut self, field: FieldAbi) -> &mut Self {
        self.fields.push(field);
        self
    }
}

#[cfg(test)]
mod test {
    use crate::abi::field::FieldAbi;
    use crate::abi::types::TypeAbi;
    use crate::serialization::ReadWrite;
    use std::io::Cursor;

    #[test]
    fn write_and_read_types() {
        let name = String::from("field1");
        let ty = String::from("u8");
        let field_abi1 = FieldAbi::new(name, ty);

        let name2 = String::from("field2");
        let ty2 = String::from("i128");

        let field_abi2 = FieldAbi::new(name2, ty2);
        let typename = String::from("type1");
        let type1 = TypeAbi {
            name: typename,
            fields: vec![field_abi1, field_abi2],
        };
        let mut buff = Cursor::new(Vec::new());
        type1.write_to(&mut buff).unwrap();
        let mut reader = Cursor::new(buff.into_inner());

        let type_read = TypeAbi::read_from(&mut reader);
        assert!(type_read == type1)
    }
}
