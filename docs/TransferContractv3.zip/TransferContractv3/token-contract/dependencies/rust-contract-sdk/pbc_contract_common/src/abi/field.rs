use crate::serialization::ReadWrite;
use read_write_derive::ReadWrite;
use serde::ser::SerializeStruct;
use serde::{Serialize, Serializer};
use std::io::{Read, Write};

#[derive(PartialEq, Eq, ReadWrite)]
pub struct FieldAbi {
    name: String,
    ty: String,
}

impl FieldAbi {
    pub fn new(name: String, ty: String) -> Self {
        FieldAbi { name, ty }
    }
}

impl Serialize for FieldAbi {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let mut field_abi = serializer.serialize_struct("FieldAbi", 2).unwrap();
        field_abi.serialize_field("name", &self.name)?;
        field_abi.serialize_field("type", &self.ty)?;
        field_abi.end()
    }
}

#[cfg(test)]
mod test {
    use std::io::Cursor;

    use crate::abi::field::FieldAbi;
    use crate::serialization::ReadWrite;

    #[test]
    fn write_and_read_fields() {
        let name = String::from("field1");
        let ty = String::from("u8");
        let field_abi1 = FieldAbi { name, ty };

        let name2 = String::from("field2");
        let ty2 = String::from("i128");
        let field_abi2 = FieldAbi {
            name: name2,
            ty: ty2,
        };

        let mut buff = Cursor::new(Vec::new());

        field_abi1.write_to(&mut buff).unwrap();
        field_abi2.write_to(&mut buff).unwrap();

        let mut reader = Cursor::new(buff.into_inner());

        let field_read1 = FieldAbi::read_from(&mut reader);
        let field_read2 = FieldAbi::read_from(&mut reader);

        assert!(field_abi1 == field_read1);
        assert!(field_abi2 == field_read2);
        assert!(field_read1 != field_read2);
    }
}
