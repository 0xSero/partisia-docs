#![feature(prelude_import)]
#[prelude_import]
use std::prelude::rust_2021::*;
#[macro_use]
extern crate std;
#[macro_use]
extern crate pbc_contract_codegen;
extern crate pbc_contract_common;
#[macro_use]
extern crate read_write_derive;
extern crate reflection;
#[macro_use]
extern crate reflection_derive;
use std::collections::BTreeMap;
use std::convert::TryInto;
use std::io::{Read, Write};
use pbc_contract_common::abi::func::FnAbi;
use pbc_contract_common::address::Address;
use pbc_contract_common::context::ContractContext;
use pbc_contract_common::serialization::{ReadInt, ReadWrite, WriteInt};
use reflection::Reflection;
#[macro_use]
extern crate lazy_static;
use reflection::Schema;
use pbc_contract_common::abi;
#[repr(C)]
pub struct TokenContractState {
    symbol: [u8; 16],
    owner: Address,
    total_supply: u64,
    balances: BTreeMap<Address, u64>,
}
impl ::core::marker::StructuralPartialEq for TokenContractState {}
#[automatically_derived]
#[allow(unused_qualifications)]
impl ::core::cmp::PartialEq for TokenContractState {
    #[inline]
    fn eq(&self, other: &TokenContractState) -> bool {
        match *other {
            TokenContractState {
                symbol: ref __self_1_0,
                owner: ref __self_1_1,
                total_supply: ref __self_1_2,
                balances: ref __self_1_3,
            } => match *self {
                TokenContractState {
                    symbol: ref __self_0_0,
                    owner: ref __self_0_1,
                    total_supply: ref __self_0_2,
                    balances: ref __self_0_3,
                } => {
                    (*__self_0_0) == (*__self_1_0)
                        && (*__self_0_1) == (*__self_1_1)
                        && (*__self_0_2) == (*__self_1_2)
                        && (*__self_0_3) == (*__self_1_3)
                }
            },
        }
    }
    #[inline]
    fn ne(&self, other: &TokenContractState) -> bool {
        match *other {
            TokenContractState {
                symbol: ref __self_1_0,
                owner: ref __self_1_1,
                total_supply: ref __self_1_2,
                balances: ref __self_1_3,
            } => match *self {
                TokenContractState {
                    symbol: ref __self_0_0,
                    owner: ref __self_0_1,
                    total_supply: ref __self_0_2,
                    balances: ref __self_0_3,
                } => {
                    (*__self_0_0) != (*__self_1_0)
                        || (*__self_0_1) != (*__self_1_1)
                        || (*__self_0_2) != (*__self_1_2)
                        || (*__self_0_3) != (*__self_1_3)
                }
            },
        }
    }
}
impl ::core::marker::StructuralEq for TokenContractState {}
#[automatically_derived]
#[allow(unused_qualifications)]
impl ::core::cmp::Eq for TokenContractState {
    #[inline]
    #[doc(hidden)]
    #[no_coverage]
    fn assert_receiver_is_total_eq(&self) -> () {
        {
            let _: ::core::cmp::AssertParamIsEq<[u8; 16]>;
            let _: ::core::cmp::AssertParamIsEq<Address>;
            let _: ::core::cmp::AssertParamIsEq<u64>;
            let _: ::core::cmp::AssertParamIsEq<BTreeMap<Address, u64>>;
        }
    }
}
#[automatically_derived]
#[allow(unused_qualifications)]
impl ::core::fmt::Debug for TokenContractState {
    fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
        match *self {
            TokenContractState {
                symbol: ref __self_0_0,
                owner: ref __self_0_1,
                total_supply: ref __self_0_2,
                balances: ref __self_0_3,
            } => {
                let debug_trait_builder =
                    &mut ::core::fmt::Formatter::debug_struct(f, "TokenContractState");
                let _ =
                    ::core::fmt::DebugStruct::field(debug_trait_builder, "symbol", &&(*__self_0_0));
                let _ =
                    ::core::fmt::DebugStruct::field(debug_trait_builder, "owner", &&(*__self_0_1));
                let _ = ::core::fmt::DebugStruct::field(
                    debug_trait_builder,
                    "total_supply",
                    &&(*__self_0_2),
                );
                let _ = ::core::fmt::DebugStruct::field(
                    debug_trait_builder,
                    "balances",
                    &&(*__self_0_3),
                );
                ::core::fmt::DebugStruct::finish(debug_trait_builder)
            }
        }
    }
}
#[automatically_derived]
#[allow(unused_qualifications)]
impl ::core::clone::Clone for TokenContractState {
    #[inline]
    fn clone(&self) -> TokenContractState {
        match *self {
            TokenContractState {
                symbol: ref __self_0_0,
                owner: ref __self_0_1,
                total_supply: ref __self_0_2,
                balances: ref __self_0_3,
            } => TokenContractState {
                symbol: ::core::clone::Clone::clone(&(*__self_0_0)),
                owner: ::core::clone::Clone::clone(&(*__self_0_1)),
                total_supply: ::core::clone::Clone::clone(&(*__self_0_2)),
                balances: ::core::clone::Clone::clone(&(*__self_0_3)),
            },
        }
    }
}
impl ::reflection::Reflection for TokenContractState {
    fn ty() -> ::reflection::Type {
        ::reflection::Type::Struct
    }
    fn name() -> ::reflection::Name {
        Some(String::from("TokenContractState"))
    }
    fn schema(id: ::reflection::Id) -> ::reflection::Schema {
        let mut tree = { ::reflection::field("_", ::reflection::Type::Struct, None, None) };
        match &mut tree.root_mut().data_mut() {
            ::reflection::Member::Field(ref mut field) => {
                field.id = id;
                field.tyname = Self::name();
                field.expander = Some(<TokenContractState as Reflection>::members);
            }
            ::reflection::Member::Variant(ref mut variant) => {
                variant.id = id;
            }
        }
        tree
    }
    fn members() -> ::reflection::Schemas {
        -(::reflection::field(
            "symbol",
            <[u8; 16] as ::reflection::Reflection>::ty(),
            <[u8; 16] as ::reflection::Reflection>::name(),
            Some(<[u8; 16] as ::reflection::Reflection>::members),
        )) - (::reflection::field(
            "owner",
            <Address as ::reflection::Reflection>::ty(),
            <Address as ::reflection::Reflection>::name(),
            Some(<Address as ::reflection::Reflection>::members),
        )) - (::reflection::field(
            "total_supply",
            <u64 as ::reflection::Reflection>::ty(),
            <u64 as ::reflection::Reflection>::name(),
            Some(<u64 as ::reflection::Reflection>::members),
        )) - (::reflection::field(
            "balances",
            <BTreeMap<Address, u64> as ::reflection::Reflection>::ty(),
            <BTreeMap<Address, u64> as ::reflection::Reflection>::name(),
            Some(<BTreeMap<Address, u64> as ::reflection::Reflection>::members),
        ))
    }
}
///Export the schema for this contract as json
#[no_mangle]
pub extern "C" fn export_contract_schema_json(dst_ptr: *mut u8, dst_len: usize) -> usize {
    0
}
impl TokenContractState {
    fn update_balance(&mut self, address: Address, delta: i64) {
        let balance = self.balances.entry(address).or_insert(0);
        if delta < 0 {
            *balance = ((*balance as i64) + delta) as u64;
        } else {
            *balance += delta as u64;
        }
    }
    fn update_total_supply(&mut self, delta: i64) {
        if delta < 0 {
            self.total_supply = ((self.total_supply as i64) + delta) as u64;
        } else {
            self.total_supply += delta as u64;
        }
    }
    fn get_balance(&self, address: Address) -> u64 {
        if let Some(balance) = self.balances.get(&address) {
            *balance
        } else {
            0
        }
    }
}
#[allow(clippy::not_unsafe_ptr_arg_deref)]
///For contract initializer: initialize
#[no_mangle]
pub extern "C" fn init(
    ctx_ptr: *const u8,
    ctx_len: usize,
    rpc_ptr: *const u8,
    rpc_len: usize,
) -> i64 {
    use std::io::Cursor;
    let rpc = unsafe { std::slice::from_raw_parts(rpc_ptr, rpc_len as usize).to_owned() };
    let mut rpc_reader = Cursor::new(rpc);
    let tmp_total_supply = rpc_reader.read_u64_be();
    let ctx = unsafe { std::slice::from_raw_parts(ctx_ptr, ctx_len as usize).to_owned() };
    let mut ctx_reader = Cursor::new(ctx);
    let context = <ContractContext>::read_from(&mut ctx_reader);
    let state = initialize(context, tmp_total_supply);
    let mut method_result: Vec<u8> = Vec::new();
    state.write_to(&mut method_result).unwrap();
    let len = method_result.len() as i64;
    let ptr = method_result.as_ptr() as i64;
    std::mem::forget(method_result);
    len << 32 | ptr
}
fn __internal_contract_init_abi__() -> pbc_contract_common::abi::func::FnAbi {
    let mut fn_abi = pbc_contract_common::abi::func::FnAbi::new("initialize".to_string());
    fn_abi.argument("ctx".to_string(), "ContractContext".to_string());
    fn_abi.argument("total_supply".to_string(), "u64".to_string());
    fn_abi
}
pub fn initialize(ctx: ContractContext, total_supply: u64) -> TokenContractState {
    let mut balances = BTreeMap::new();
    balances.insert(ctx.sender, total_supply);
    TokenContractState {
        symbol: [0; 16],
        owner: ctx.sender,
        total_supply,
        balances,
    }
}
#[allow(clippy::not_unsafe_ptr_arg_deref)]
///For contract action: mint
#[no_mangle]
pub extern "C" fn action_BB176FDC(
    ctx_ptr: *const u8,
    ctx_len: usize,
    state_ptr: *const u8,
    state_len: usize,
    rpc_ptr: *const u8,
    rpc_len: usize,
) -> i64 {
    use std::io::Cursor;
    let rpc = unsafe { std::slice::from_raw_parts(rpc_ptr, rpc_len as usize).to_owned() };
    let mut rpc_reader = Cursor::new(rpc);
    let tmp_amount = rpc_reader.read_u64_be();
    let ctx = unsafe { std::slice::from_raw_parts(ctx_ptr, ctx_len as usize).to_owned() };
    let mut ctx_reader = Cursor::new(ctx);
    let state_slice =
        unsafe { std::slice::from_raw_parts(state_ptr, state_len as usize).to_owned() };
    let mut state_reader = Cursor::new(state_slice);
    let context = <ContractContext>::read_from(&mut ctx_reader);
    let prev_state = <TokenContractState>::read_from(&mut state_reader);
    let state = mint(context, prev_state, tmp_amount);
    let mut method_result: Vec<u8> = Vec::new();
    state.write_to(&mut method_result).unwrap();
    let len = method_result.len() as i64;
    let ptr = method_result.as_ptr() as i64;
    std::mem::forget(method_result);
    len << 32 | ptr
}
pub fn mint(
    context: ContractContext,
    state: TokenContractState,
    amount: u64,
) -> TokenContractState {
    {
        match (&context.sender, &state.owner) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = ::core::panicking::AssertKind::Eq;
                    ::core::panicking::assert_failed(
                        kind,
                        &*left_val,
                        &*right_val,
                        ::core::option::Option::Some(::core::fmt::Arguments::new_v1(
                            &["Mint only allowed for owner."],
                            &match () {
                                () => [],
                            },
                        )),
                    );
                }
            }
        }
    };
    let mut new_state = state.clone();
    new_state.update_balance(state.owner, amount.try_into().unwrap());
    new_state.update_total_supply(amount.try_into().unwrap());
    new_state
}
pub fn abi_BB176FDC() -> FnAbi {
    let mut function = FnAbi::new("BB176FDC".to_string());
    function.argument(String::from("context"), String::from("ContractContext"));
    function.argument(String::from("state"), String::from("TokenContractState"));
    function.argument(String::from("amount"), String::from("u64"));
    function
}
#[no_mangle]
pub extern "C" fn abi_func_BB176FDC_to_ptr(ptr: *mut u8) -> u32 {
    let v_BB176FDC_abi = abi_BB176FDC();
    pbc_contract_common::fn_abi_to_ptr(v_BB176FDC_abi, ptr)
}
#[allow(clippy::not_unsafe_ptr_arg_deref)]
///For contract action: transfer
#[no_mangle]
pub extern "C" fn action_CA76F527(
    ctx_ptr: *const u8,
    ctx_len: usize,
    state_ptr: *const u8,
    state_len: usize,
    rpc_ptr: *const u8,
    rpc_len: usize,
) -> i64 {
    use std::io::Cursor;
    let rpc = unsafe { std::slice::from_raw_parts(rpc_ptr, rpc_len as usize).to_owned() };
    let mut rpc_reader = Cursor::new(rpc);
    let tmp_dest = <Address>::read_from(&mut rpc_reader);
    let tmp_amount = rpc_reader.read_u64_be();
    let ctx = unsafe { std::slice::from_raw_parts(ctx_ptr, ctx_len as usize).to_owned() };
    let mut ctx_reader = Cursor::new(ctx);
    let state_slice =
        unsafe { std::slice::from_raw_parts(state_ptr, state_len as usize).to_owned() };
    let mut state_reader = Cursor::new(state_slice);
    let context = <ContractContext>::read_from(&mut ctx_reader);
    let prev_state = <TokenContractState>::read_from(&mut state_reader);
    let state = transfer(context, prev_state, tmp_dest, tmp_amount);
    let mut method_result: Vec<u8> = Vec::new();
    state.write_to(&mut method_result).unwrap();
    let len = method_result.len() as i64;
    let ptr = method_result.as_ptr() as i64;
    std::mem::forget(method_result);
    len << 32 | ptr
}
pub fn transfer(
    context: ContractContext,
    state: TokenContractState,
    dest: Address,
    amount: u64,
) -> TokenContractState {
    let mut new_state = state;
    if !(new_state.get_balance(context.sender) >= amount) {
        ::core::panicking::panic_fmt(::core::fmt::Arguments::new_v1(
            &["Amount > balance"],
            &match () {
                () => [],
            },
        ))
    };
    let delta = amount.try_into().unwrap();
    new_state.update_balance(dest, delta);
    new_state.update_balance(context.sender, -delta);
    new_state
}
pub fn abi_CA76F527() -> FnAbi {
    let mut function = FnAbi::new("CA76F527".to_string());
    function.argument(String::from("context"), String::from("ContractContext"));
    function.argument(String::from("state"), String::from("TokenContractState"));
    function.argument(String::from("dest"), String::from("Address"));
    function.argument(String::from("amount"), String::from("u64"));
    function
}
#[no_mangle]
pub extern "C" fn abi_func_CA76F527_to_ptr(ptr: *mut u8) -> u32 {
    let v_CA76F527_abi = abi_CA76F527();
    pbc_contract_common::fn_abi_to_ptr(v_CA76F527_abi, ptr)
}
