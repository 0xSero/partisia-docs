The `reflection` crate currently provides reflection of field names and type names.

See the sub directory `reflection_test` for quickstart.

Licensed under MIT.
