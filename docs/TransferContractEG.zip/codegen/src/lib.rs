#![recursion_limit = "128"]
extern crate pbc_external;
extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate sha2;
extern crate syn;

use proc_macro::TokenStream;
use std::convert::TryInto;

use proc_macro2::Span;
use quote::ToTokens;
use sha2::{Digest, Sha256};
use syn::{FnArg, Ident, ReturnType, Type, TypePath};
use syn::__private::TokenStream2;

use pbc_contract_common::serialization::WriteInt;

#[proc_macro_attribute]
pub fn state(_attrs: TokenStream, input: TokenStream) -> TokenStream {
    let original_state_item: proc_macro2::TokenStream = input.into();

    let result = quote! {
        // TODO [tth]: Can we do this without lazy_static?
        #[macro_use]
        extern crate lazy_static;

        use reflection::Schema;

        // TODO [tth]: Consider if we should derive PartialEq, Eq and Debug by default.
        //  #[repr(C)] is probably not needed as the struct itself it not passed via FFI.
        #[repr(C)]
        #[derive(PartialEq, Eq, Debug, Clone, Reflection)]
        #original_state_item
    };

    result.into()
}

#[proc_macro_attribute]
pub fn init(_attrs: TokenStream, input: TokenStream) -> TokenStream {
    let fn_ast: syn::ItemFn = syn::parse(input.clone()).unwrap();
    // TODO [tth] validate that the first argument is contract context.
    // TODO [tth] validate that the return type is "state".

    let (var_name, expression) = variables_for_inner_call(&fn_ast);

    let fn_identifier = fn_ast.sig.ident.clone();
    let export_symbol = format_ident!("action_9e4dc145");
    let raw_fn_name = fn_identifier.to_string();
    let docs = format!("For contract initializer: {}", raw_fn_name.clone());

    let mut result = wrap_function_for_export(
        fn_identifier,
        export_symbol.clone(),
        docs,
        var_name,
        expression,
    );
    result.extend(TokenStream2::from(input));
    result.into()
}

#[proc_macro_attribute]
pub fn action(_attrs: TokenStream, input: TokenStream) -> TokenStream {
    let fn_ast: syn::ItemFn = syn::parse(input.clone()).unwrap();
    // TODO [tth] validate that the first argument is contract context.
    // TODO [tth] validate that the second argument is "state".
    // TODO [tth] validate that the return type is "state".

    let (var_name, expression) = variables_for_inner_call(&fn_ast);

    let fn_identifier = fn_ast.sig.ident.clone();

    let fn_name_hash = hash_identifier(&fn_identifier);
    let export_symbol = format_ident!("action_{:x}", fn_name_hash);
    let raw_fn_name = fn_identifier.to_string();
    let docs = format!("For contract action: {}", raw_fn_name.clone());

    let mut result = wrap_function_for_export(
        fn_identifier,
        export_symbol.clone(),
        docs,
        var_name,
        expression,
    );

    result.extend(TokenStream2::from(input));
    result.into()
}

fn hash_identifier(ident: &Ident) -> u32 {
    let raw_name = ident.to_string();
    let mut digest = Sha256::new();
    Digest::update(&mut digest, raw_name.as_bytes());
    let output = digest.finalize();
    let last_four_bytes = output.chunks(4).next().unwrap();
    let new_function_identifier = u32::from_le_bytes(last_four_bytes.try_into().unwrap());
    new_function_identifier
}

fn wrap_function_for_export(
    fn_identifier: Ident,
    export_symbol: Ident,
    docs: String,
    var_name: Vec<TokenStream2>,
    expression: Vec<TokenStream2>,
) -> TokenStream2 {
    quote! {
        #[doc = #docs]
        #[no_mangle]
        pub extern "C" fn #export_symbol(rpc_ptr: *const u8, rpc_len: usize) -> *const u8 {
            use std::io::Cursor;

            let rpc = unsafe { std::slice::from_raw_parts(rpc_ptr, rpc_len as usize).to_owned() };
            let mut cursor = Cursor::new(rpc);

            // The expressions, which are used to evaluate the arguments for the inner function,
            // deserialize from "cursor" meaning they have side effects.
            // Because of this, we need to ensure that they are evaluated in the correct order,
            // thus we will bind them to variables instead of #fn_identifier(#(#expression),*)
            // (since function arguments are not guaranteed to evaluate left to right).
            #(let #var_name = #expression)*
            let state = #fn_identifier(#(#var_name),*);

            let mut method_result: Vec<u8> = Vec::new();
            state.write_to(&mut method_result).unwrap();

            let len = method_result.len();

            let mut output : Vec<u8> = Vec::with_capacity(len + 4);
            output.write_u32_be(len as u32);
            output.append(&mut method_result);

            let ptr = output.as_ptr();
            std::mem::forget(output);

            ptr
        }
    }
}

fn read_fn_arguments(item: &syn::ItemFn) -> (Vec<String>, Vec<String>) {
    let mut names = Vec::new();
    let mut types = Vec::new();
    for token in item.sig.inputs.iter() {
        match token {
            FnArg::Receiver(_) => {
                panic!("Contract functions cannot be part of an `impl`.")
            }
            FnArg::Typed(pat) => {
                let identifier = pat.pat.to_token_stream();
                let ty = pat.ty.to_token_stream();
                names.push(identifier.to_string());
                types.push(ty.to_string());
            }
        }
    }

    (names, types)
}

fn variables_for_inner_call(item: &syn::ItemFn) -> (Vec<TokenStream2>, Vec<TokenStream2>) {
    let mut var_name: Vec<TokenStream2> = Vec::new();
    let mut expression: Vec<TokenStream2> = Vec::new();

    for token in item.sig.inputs.iter() {
        let (name, expr) = extract_name_and_expression(token);
        var_name.push(name);
        expression.push(expr);
    }
    (var_name, expression)
}

fn extract_name_and_expression(token: &FnArg) -> (TokenStream2, TokenStream2) {
    match token {
        FnArg::Receiver(_) => {
            // TODO [tth]: Note that self receivers with a specified type,
            //  such as self: Box<Self>, are parsed as a FnArg::Typed.
            panic!("Contract functions cannot be part of an `impl`.")
        }
        FnArg::Typed(pat) => {
            let name = pat.pat.to_token_stream().to_string();
            let variable_identifier = format_ident!("tmp_{}", name);
            let var_name = quote! {#variable_identifier};
            let ty = *(pat.ty.clone());
            match ty {
                Type::Path(path) => {
                    let expr = generate_instantiating_expression(path);
                    (var_name, expr)
                }
                Type::Tuple(_) => {
                    panic!("Unsupported tuple type");
                }
                Type::Array(_) => {
                    panic!("Unsupported array type");
                }
                Type::ImplTrait(_) => {
                    panic!("Unsupported impl trait type");
                }
                Type::Reference(_) => {
                    panic!("Unsupported reference type");
                }
                Type::Slice(_) => {
                    panic!("Unsupported slice type");
                }
                _ => {
                    panic!("Unsupported argument type")
                }
            }
        }
    }
}

fn generate_instantiating_expression(path: TypePath) -> TokenStream2 {
    match path.path.get_ident() {
        Some(ident) => {
            if ident.eq(&Ident::new("u64", Span::call_site())) {
                quote! {cursor.read_u64_be();}
            } else if ident.eq(&Ident::new("i64", Span::call_site())) {
                quote! {cursor.read_i64_be();}
            } else if ident.eq(&Ident::new("i32", Span::call_site())) {
                quote! {cursor.read_i32_be();}
            } else {
                quote! {<#ident>::read_from(&mut cursor);}
            }
        }
        None => {
            let tokens = path.path.segments.into_token_stream();
            quote! {<#tokens>::read_from(&mut cursor);}
        }
    }
}
