extern crate reflection;
#[macro_use]
extern crate reflection_derive;

use reflection::Member;
use serde_json::{Map, Value};
use serde_json::value::Value::Object;
use trees::Node;

pub mod address;
pub mod base;
pub mod context;
pub mod hash;
pub mod serialization;
mod types;

