pub struct Types {
    pub(crate) types: Vec<String>,
}

impl Types {
    pub fn new() -> Types {
        let vec: Vec<String> = vec![
            String::from("CUSTOM_STRUCT"),
            String::from("u8"),
            String::from("u16"),
            String::from("u32"),
            String::from("u64"),
            String::from("u128"),
            String::from("i8"),
            String::from("i16"),
            String::from("i32"),
            String::from("i64"),
            String::from("i128"),
            String::from("Vec<T>"),
            String::from("BTreeMap"),
            String::from("BTreeSet"),
        ];

        Types { types: vec }
    }

    // pub fn get_type(&self, number: u8) -> Option<&String> {self.int_to_type.get(&number)}
    pub fn get_type(&self, number: u8) -> Option<&String> {
        self.types.get(number as usize)
    }

    pub fn get_int(&self, ty: &String) -> Option<u8> {
        let int = self.types.iter().position(|x| x.eq(ty));
        match int {
            None => panic!("Type does not exist"),
            Some(val) => Some(val as u8),
        }
    }
}
