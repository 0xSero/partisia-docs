#[macro_use]
extern crate pbc_contract_codegen;
extern crate pbc_contract_common;
extern crate reflection;
#[macro_use]
extern crate reflection_derive;

use std::collections::BTreeMap;
use std::convert::TryInto;
use std::io::{Read, Write};

use reflection::Reflection;

use pbc_contract_common::address::Address;
use pbc_contract_common::base::info;
use pbc_contract_common::context::ContractContext;
use pbc_contract_common::serialization::{ReadInt, ReadWrite, WriteInt};

#[state]
pub struct TokenContractState {
    symbol: [u8; 16],
    total_supply: u64,
    balances: BTreeMap<Address, u64>,
}

impl TokenContractState {
    fn update_balance(&mut self, address: Address, delta: i64) {
        let balance = self.balances.entry(address).or_insert(0);
        if delta < 0 {
            *balance = ((*balance as i64) + delta) as u64;
        } else {
            *balance += delta as u64;
        }
    }

    fn get_balance(&self, address: Address) -> u64 {
        if let Some(balance) = self.balances.get(&address) {
            *balance
        } else {
            0
        }
    }
}

impl ReadWrite for TokenContractState {
    fn read_from<T: Read>(reader: &mut T) -> Self {
        let mut symbol = [0u8; 16];
        reader.read_exact(&mut symbol).unwrap();

        let total_supply = reader.read_u64_be();

        let balances: BTreeMap<Address, u64> = BTreeMap::read_from(reader);
        TokenContractState {
            symbol,
            total_supply,
            balances,
        }
    }

    fn write_to<T: Write + WriteInt>(&self, writer: &mut T) -> std::io::Result<()> {
        writer.write_all(&self.symbol)?;
        writer.write_u64_be(self.total_supply)?;
        self.balances.write_to(writer)?;

        Ok(())
    }
}

#[init]
pub fn initialize(
    ctx: ContractContext,
    base_state: Option<TokenContractState>,
) -> TokenContractState {
    if let Some(state) = base_state {
        let mut init_state = state.clone();
        init_state.update_balance(ctx.sender, state.total_supply.try_into().unwrap());
        init_state
    } else {
        let mut balances = BTreeMap::new();
        balances.insert(ctx.sender, 0);
        TokenContractState {
            symbol: [0; 16],
            total_supply: 0,
            balances,
        }
    }
}

#[action]
pub fn mint(
    context: ContractContext,
    state: TokenContractState,
    amount: u64,
) -> TokenContractState {
    assert_eq!(
        context.sender, context.owner,
        "Mint only allowed for owner."
    );
    let mut new_state = state.clone();
    new_state.update_balance(context.owner, amount.try_into().unwrap());
    new_state
}

#[action]
pub fn transfer(
    context: ContractContext,
    state: TokenContractState,
    dest: Address,
    amount: u64,
) -> TokenContractState {
    let mut new_state = state.clone();
    assert!(
        new_state.get_balance(context.sender) >= amount,
        "Amount > balance"
    );

    let delta = amount.try_into().unwrap();
    new_state.update_balance(dest, delta);
    new_state.update_balance(context.sender, -delta);
    new_state
}

