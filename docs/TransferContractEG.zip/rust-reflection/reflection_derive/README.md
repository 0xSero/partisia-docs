The `reflection_derive` crate provides the proc-macro implementation for the `reflection` crate.

Licensed under MIT.
