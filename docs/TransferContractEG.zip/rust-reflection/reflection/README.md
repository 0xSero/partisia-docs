The `reflection` crate currently provides reflection of field names and type names.

[Quickstart](https://github.com/oooutlk/reflection/blob/master/reflection_test/src/lib.rs)

Licensed under MIT.
