use std::collections::BTreeMap;
use std::error::Error;
use std::fs::File;
use std::io::Write;
use std::str::FromStr;

use pbc_contract_common::abi::ContractAbi;
use pbc_contract_common::abi::FnAbi;
use pbc_contract_common::abi::SemVer;
use pbc_contract_common::abi::TypeAbi;
use pbc_contract_common::abi::TypeKey;
use pbc_contract_common::abi::VERSION_BINDER;
use pbc_contract_common::abi::VERSION_CLIENT;
use pbc_traits::ReadWriteState;
use regex::Regex;
use wasmtime::*;

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = std::env::args().collect();
    if args.contains(&"-v".to_string()) {
        println!(
            "pbc-abigen binder version: {} sdk version: {}",
            VERSION_BINDER, VERSION_CLIENT
        );
        return Ok(());
    }
    if args.len() != 3 {
        println!("Usage: pbc-abigen <wasm> <abi output>");
        return Err("Missing arguments".into());
    }

    let wasm = &args[1];
    let bin = &args[2];
    read_wasm_and_write_abi(wasm, bin)
}

fn read_wasm_and_write_abi(wasm_file: &str, bin_file: &str) -> Result<(), Box<dyn Error>> {
    let engine = Engine::default();
    let module = Module::from_file(&engine, wasm_file)?;

    let mut store = Store::new(&engine, "");
    let mut linker = Linker::new(&engine);

    linker
        .func_wrap("ext", "log_external", |_p0: i64, _p1: i32| {})
        .expect("failed to wrap function call_named");

    let instance = linker.instantiate(&mut store, &module)?;
    let memory = instance.get_memory(&mut store, "memory").unwrap();

    let old_size = memory.size(&store);
    // Allocate 640k ram
    memory.grow(&mut store, 100).unwrap();

    let mut base_pointer = (old_size * 65536) as i32;

    let lut_pointer = base_pointer;

    {
        let mut out: Vec<u8> = Vec::new();
        let lut: BTreeMap<TypeKey, u8> = BTreeMap::new();
        lut.state_write_to(&mut out).unwrap();

        memory.write(&mut store, base_pointer as usize, &out)?;

        base_pointer += out.len() as i32;
    }

    let mut types: Vec<TypeAbi> = Vec::new();
    for export in module.exports() {
        let export_name = export.name();
        if export_name.starts_with("abi_type_") {
            let abi_type = get_fun_or_panic(&instance, &mut store, export_name);

            let type_abi: TypeAbi =
                read_from_ffi(&mut store, base_pointer, &memory, abi_type, lut_pointer);
            types.push(type_abi)
        }
    }

    let mut lut: BTreeMap<TypeKey, u8> = BTreeMap::new();
    for (index, type_abi) in types.iter().enumerate() {
        lut.insert(type_abi.type_key.clone(), index as u8);
    }

    let lut_pointer = base_pointer;
    {
        let mut out: Vec<u8> = Vec::new();
        lut.state_write_to(&mut out).unwrap();

        memory.write(&mut store, base_pointer as usize, &out)?;

        base_pointer += out.len() as i32;
    }

    let mut types: Vec<TypeAbi> = Vec::new();
    let mut actions: Vec<FnAbi> = Vec::new();
    for export in module.exports() {
        let export_name = export.name();
        if export_name.starts_with("abi_type_") {
            let abi_type = get_fun_or_panic(&instance, &mut store, export_name);

            let type_abi: TypeAbi =
                read_from_ffi(&mut store, base_pointer, &memory, abi_type, lut_pointer);
            types.push(type_abi)
        }

        if export_name.starts_with("__abi_fn_") {
            let abi_fn = get_fun_or_panic(&instance, &mut store, export_name);
            let fn_abi: FnAbi =
                read_from_ffi(&mut store, base_pointer, &memory, abi_fn, lut_pointer);
            actions.push(fn_abi);
        }
    }

    let state_name_fn = get_fun_or_panic(&instance, &mut store, "__abi_state_name");
    let state: String = read_from_ffi(
        &mut store,
        base_pointer,
        &memory,
        state_name_fn,
        lut_pointer,
    );

    let init_abi_fn = get_fun_or_panic(&instance, &mut store, "__abi_func_init_to_ptr");
    let init: FnAbi = read_from_ffi(&mut store, base_pointer, &memory, init_abi_fn, lut_pointer);

    let potential_state_indices: Vec<usize> = types
        .iter()
        .enumerate()
        .filter(|(_, type_abi)| type_abi.name == state)
        .map(|(idx, _)| idx)
        .collect();

    assert_eq!(
        potential_state_indices.len(),
        1,
        "More than one type named {}",
        state
    );

    let state_index = potential_state_indices.get(0).cloned().unwrap();

    let state_type: &TypeAbi = types.get(state_index).unwrap();
    let mut ordinals = state_type.type_key.ordinals.clone();
    if ordinals[0] == 0 {
        ordinals.insert(0, 0);
    }

    let version_client_sdk =
        extract_version(&find_export_or_else(&module, "__PBC_VERSION_CLIENT_"))?;
    let version_binder_sdk =
        extract_version(&find_export_or_else(&module, "__PBC_VERSION_BINDER_"))?;

    if VERSION_BINDER != version_binder_sdk {
        return Err(
            format!(
                "Version mismatch! Binder versions pbc-abigen: {} sdk: {}.Please recompile WASM before running pbc-abigen.",
                VERSION_BINDER, version_binder_sdk).into()
        );
    }

    if VERSION_CLIENT != version_client_sdk {
        return Err(
            format!(
                "Version mismatch! Client versions pbc-abigen: {} sdk: {}. Please recompile WASM before running pbc-abigen.",
                VERSION_CLIENT, version_client_sdk).into()
        );
    }

    let mut contract = ContractAbi::new(init, ordinals);
    contract.actions(actions);
    contract.types(types);

    write_as_binary(&contract, bin_file)?;

    Ok(())
}

fn find_export_or_else(module: &Module, prefix: &str) -> String {
    let export = module
        .exports()
        .find(|export| export.name().to_string().starts_with(prefix));
    match export {
        None => "".to_string(),
        Some(export) => export.name().to_string(),
    }
}

fn extract_version(name: &str) -> Result<SemVer, Box<dyn Error>> {
    let regex = Regex::new(r"(?P<major>\d+)_(?P<minor>\d+)_(?P<patch>\d+)").unwrap();
    let caps = regex
        .captures(name)
        .ok_or("Could not find version in WASM file.")?;
    let major = caps
        .name("major")
        .map(|m| u8::from_str(m.as_str()).unwrap())
        .ok_or_else(|| "Invalid major version".to_string())?;

    let minor = caps
        .name("minor")
        .map(|m| u8::from_str(m.as_str()).unwrap())
        .ok_or_else(|| "Invalid minor version".to_string())?;

    let patch = caps
        .name("patch")
        .map(|m| u8::from_str(m.as_str()).unwrap())
        .ok_or_else(|| "Invalid patch version".to_string())?;

    Ok(SemVer::new(major, minor, patch))
}

/// Create a header for the given version
pub fn abi_header_bytes() -> [u8; 12] {
    let mut bytes = [0u8; 12];
    for (i, byte) in "PBCABI".as_bytes().iter().enumerate() {
        bytes[i] = *byte;
    }
    bytes[6] = VERSION_BINDER.major;
    bytes[7] = VERSION_BINDER.minor;
    bytes[8] = VERSION_BINDER.patch;

    bytes[9] = VERSION_CLIENT.major;
    bytes[10] = VERSION_CLIENT.minor;
    bytes[11] = VERSION_CLIENT.patch;

    bytes
}

fn write_as_binary(contract: &ContractAbi, filename: &str) -> std::io::Result<()> {
    let mut file = File::create(filename.to_string())?;
    file.write_all(&abi_header_bytes())?;
    contract.serialize_abi(&mut file)
}

fn read_from_ffi<T: ReadWriteState>(
    mut store: &mut Store<&str>,
    base_pointer: i32,
    memory: &Memory,
    wasm_fn: Func,
    lut_pointer: i32,
) -> T {
    let size = wasm_fn
        .call(&mut store, &[Val::I32(base_pointer), Val::I32(lut_pointer)])
        .expect("Call failed");
    let usize_size = size.first().unwrap().i32().unwrap() as usize;

    let base_pointer_native = base_pointer as usize;
    let mut content_buffer =
        &memory.data(&store)[base_pointer_native..base_pointer_native + usize_size];
    T::state_read_from(&mut content_buffer)
}

fn get_fun_or_panic(instance: &Instance, store: &mut Store<&str>, export_name: &str) -> Func {
    instance
        .get_func(store, export_name)
        .unwrap_or_else(|| panic!("{} is not an exported function", export_name))
}

#[test]
fn test_extract_version() {
    assert_eq!(extract_version("1_2_3").unwrap(), SemVer::new(1, 2, 3));
    assert_eq!(extract_version("255_254_253").unwrap(), SemVer::new(255, 254, 253));
    assert_eq!(
        extract_version("").err().unwrap().to_string(),
        "Could not find version in WASM file."
    );
    //assert_eq!(
    //    extract_version("1_256_999").err().unwrap().to_string(),
    //    "Could not find version in WASM file."
    //);
}
