//! Common functions used in the procedural macros in the SDK.
extern crate proc_macro;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;
use syn::parse_quote::parse;
use syn::{Data, Expr, Field, Fields, Ident, Type};

/// Extracts a fields identifier
///
/// # Arguments
/// * `field` Field to extract identifier from.
pub fn field_to_name(field: &Field) -> Ident {
    field.ident.clone().unwrap()
}

/// Implement a named trait that has read and a write methods.
/// The signature matches `ReadWriteRPC` and `ReadWriteState`.
///
/// # Arguments
/// * `ast` - A Abstract Syntax Tree of the struct calling the procedural macro.
/// * `trait_name` - Identifier
/// * `read_method` - Identifier
/// * `write_method` - Identifier
pub fn impl_read_write(
    ast: &syn::DeriveInput,
    trait_name: Ident,
    read_method: Ident,
    write_method: Ident,
) -> proc_macro2::TokenStream {
    let name = &ast.ident;
    let fieldnames = fields_to_names(&ast.data);
    let (read_logic, write_logic) =
        make_read_and_write_logic(&ast.data, &read_method, &write_method);

    quote! {
        impl pbc_traits::#trait_name for #name {
            fn #read_method<T: Read>(reader: &mut T) -> Self {
                #read_logic
                #name {
                    #(#fieldnames),*
                }
            }

            fn #write_method<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
                #write_logic
            }
        }
    }
}

/// Extracts the type from a field
///
/// * `field` - Field to extract type from.
pub fn field_to_type(field: &Field) -> TokenStream {
    let ty: TokenStream = match &field.ty {
        Type::Path(path) => path.clone().to_token_stream(),
        Type::Array(arr) => {
            let ident = match arr.elem.as_ref() {
                Type::Path(type_path) => type_path
                    .path
                    .segments
                    .last()
                    .unwrap()
                    .clone()
                    .ident
                    .to_token_stream(),
                _ => unimplemented!("Not implemented"),
            };

            let len = match &arr.len {
                Expr::Lit(literal_expr) => Some(literal_expr.lit.to_token_stream()),
                _ => unimplemented!("Not implemented"),
            };

            parse(quote!([#ident; #len]))
        }
        _ => unimplemented!("Unknown type."),
    };
    ty.to_token_stream()
}

/// Attempts to convert the given AST element to a list of Idents.
/// If the data given is not an AST struct, it fails with a panic.
fn fields_to_names(data: &Data) -> Vec<Ident> {
    let list_of_names: Vec<Ident> = match *data {
        Data::Struct(ref data) => match data.fields {
            Fields::Named(ref fields) => fields.named.iter().map(field_to_name).collect(),
            _ => unimplemented!("Only named fields are supported"),
        },
        _ => unimplemented!("Only structs are supported"),
    };

    list_of_names
}

/// Implement read/write logic for a struct.
/// This code is shared between `ReadWriteRPC` and `ReadWriteState`.
fn make_read_and_write_logic(
    data: &Data,
    read_method: &Ident,
    write_method: &Ident,
) -> (proc_macro2::TokenStream, proc_macro2::TokenStream) {
    match *data {
        Data::Struct(ref data) => match data.fields {
            Fields::Named(ref fields) => {
                let names: Vec<Ident> = fields.named.iter().map(field_to_name).collect();
                let types: Vec<TokenStream> = fields.named.iter().map(field_to_type).collect();

                // For all (names, types) write `let name_n = type_n::read_method(reader)`.
                let read_lines = quote! {
                    #(
                        let #names =  <#types>::#read_method(reader);
                    )*
                };

                // For all (names, types) write `self.field_n::write_method(reader)?`.
                let write_lines = quote! {
                    #(
                        <#types>::#write_method(&self.#names, writer)?;
                    )*
                    return Ok(());
                };

                (read_lines, write_lines)
            }
            _ => unimplemented!("Only named fields are supported"),
        },
        _ => unimplemented!("Only structs are supported"),
    }
}
