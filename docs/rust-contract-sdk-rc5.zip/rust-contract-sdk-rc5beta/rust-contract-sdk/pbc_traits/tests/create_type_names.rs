use std::collections::{BTreeMap, BTreeSet};

use pbc_traits::CreateTypeSpec;

#[test]
pub fn ty_names_simple_types() {
    assert_eq!(u8::__ty_name(), "u8");
    assert_eq!(i8::__ty_name(), "i8");
    assert_eq!(u16::__ty_name(), "u16");
    assert_eq!(i16::__ty_name(), "i16");
    assert_eq!(u32::__ty_name(), "u32");
    assert_eq!(i32::__ty_name(), "i32");
    assert_eq!(u64::__ty_name(), "u64");
    assert_eq!(i64::__ty_name(), "i64");
    assert_eq!(u128::__ty_name(), "u128");
    assert_eq!(i128::__ty_name(), "i128");
    assert_eq!(String::__ty_name(), "String");
    assert_eq!(bool::__ty_name(), "bool");
}

#[test]
pub fn ty_names_complex_types() {
    assert_eq!(<BTreeMap<u8, i8>>::__ty_name(), "BTreeMap<u8, i8>");
    assert_eq!(<BTreeSet<String>>::__ty_name(), "BTreeSet<String>");
    assert_eq!(<Vec<String>>::__ty_name(), "Vec<String>");

    assert_eq!(
        <Vec<Vec<Vec<BTreeSet<BTreeMap<i128, Vec<BTreeSet<String>>>>>>>>::__ty_name(),
        "Vec<Vec<Vec<BTreeSet<BTreeMap<i128, Vec<BTreeSet<String>>>>>>>"
    );
}

#[test]
pub fn ty_names_arrays() {
    assert_eq!(<[u8; 1]>::__ty_name(), "[u8; 1]");
    assert_eq!(<[u8; 2]>::__ty_name(), "[u8; 2]");
    assert_eq!(<[u8; 3]>::__ty_name(), "[u8; 3]");
    assert_eq!(<[u8; 4]>::__ty_name(), "[u8; 4]");
    assert_eq!(<[u8; 5]>::__ty_name(), "[u8; 5]");
    assert_eq!(<[u8; 6]>::__ty_name(), "[u8; 6]");
    assert_eq!(<[u8; 7]>::__ty_name(), "[u8; 7]");
    assert_eq!(<[u8; 8]>::__ty_name(), "[u8; 8]");
    assert_eq!(<[u8; 9]>::__ty_name(), "[u8; 9]");
    assert_eq!(<[u8; 10]>::__ty_name(), "[u8; 10]");
    assert_eq!(<[u8; 11]>::__ty_name(), "[u8; 11]");
    assert_eq!(<[u8; 12]>::__ty_name(), "[u8; 12]");
    assert_eq!(<[u8; 13]>::__ty_name(), "[u8; 13]");
    assert_eq!(<[u8; 14]>::__ty_name(), "[u8; 14]");
    assert_eq!(<[u8; 15]>::__ty_name(), "[u8; 15]");
    assert_eq!(<[u8; 16]>::__ty_name(), "[u8; 16]");
    assert_eq!(<[u8; 17]>::__ty_name(), "[u8; 17]");
    assert_eq!(<[u8; 18]>::__ty_name(), "[u8; 18]");
    assert_eq!(<[u8; 19]>::__ty_name(), "[u8; 19]");
    assert_eq!(<[u8; 20]>::__ty_name(), "[u8; 20]");
    assert_eq!(<[u8; 21]>::__ty_name(), "[u8; 21]");
    assert_eq!(<[u8; 22]>::__ty_name(), "[u8; 22]");
    assert_eq!(<[u8; 23]>::__ty_name(), "[u8; 23]");
    assert_eq!(<[u8; 24]>::__ty_name(), "[u8; 24]");
    assert_eq!(<[u8; 25]>::__ty_name(), "[u8; 25]");
    assert_eq!(<[u8; 26]>::__ty_name(), "[u8; 26]");
    assert_eq!(<[u8; 27]>::__ty_name(), "[u8; 27]");
    assert_eq!(<[u8; 28]>::__ty_name(), "[u8; 28]");
    assert_eq!(<[u8; 29]>::__ty_name(), "[u8; 29]");
    assert_eq!(<[u8; 30]>::__ty_name(), "[u8; 30]");
    assert_eq!(<[u8; 31]>::__ty_name(), "[u8; 31]");
    assert_eq!(<[u8; 32]>::__ty_name(), "[u8; 32]");
}

fn assert_ty<T: CreateTypeSpec>(ord: &[u8]) {
    let mut vec = Vec::new();
    T::__ty_ordinal(&mut vec);
    assert_eq!(&vec, ord);
}

#[test]
pub fn ty_names_and_ordinal() {
    assert_ty::<u8>(&[0x01]);
    assert_ty::<u16>(&[0x02]);
    assert_ty::<u32>(&[0x03]);
    assert_ty::<u64>(&[0x04]);
    assert_ty::<u128>(&[0x05]);

    assert_ty::<i8>(&[0x06]);
    assert_ty::<i16>(&[0x07]);
    assert_ty::<i32>(&[0x08]);
    assert_ty::<i64>(&[0x09]);
    assert_ty::<i128>(&[0x0a]);

    assert_ty::<String>(&[0x0b]);
    assert_ty::<bool>(&[0x0c]);

    assert_ty::<Vec<u8>>(&[0x0e, 0x01]);
    assert_ty::<Vec<u16>>(&[0x0e, 0x02]);
    assert_ty::<Vec<u32>>(&[0x0e, 0x03]);
    assert_ty::<Vec<u64>>(&[0x0e, 0x04]);
    assert_ty::<Vec<u128>>(&[0x0e, 0x05]);

    assert_ty::<Vec<i8>>(&[0x0e, 0x06]);
    assert_ty::<Vec<i16>>(&[0x0e, 0x07]);
    assert_ty::<Vec<i32>>(&[0x0e, 0x08]);
    assert_ty::<Vec<i64>>(&[0x0e, 0x09]);
    assert_ty::<Vec<i128>>(&[0x0e, 0x0a]);

    assert_ty::<BTreeSet<i128>>(&[0x10, 0x0a]);
    assert_ty::<BTreeMap<i128, u128>>(&[0x0f, 0x0a, 0x05]);

    assert_ty::<BTreeMap<Vec<BTreeMap<Vec<Vec<String>>, BTreeSet<BTreeMap<u32, u64>>>>, u128>>(&[
        0x0f, 0x0e, 0x0f, 0x0e, 0x0e, 0x0b, 0x10, 0x0f, 0x03, 0x04, 0x05,
    ]);
}
