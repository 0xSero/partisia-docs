//! Adds the runtime type information needed to generate the PBC ABI.
//! See [ABI spec](https://privacyblockchain.gitlab.io/language/rust-contract-sdk/abiv1.html)
#[macro_use]
extern crate quote;

pub use create_type_spec::CreateTypeSpec;
pub use read_int::ReadInt;
pub use readwrite_rpc::ReadWriteRPC;
pub use readwrite_state::ReadWriteState;
pub use write_int::WriteInt;

mod create_type_spec;
mod read_int;
mod readwrite_rpc;
mod readwrite_state;
mod write_int;
