use std::collections::{BTreeMap, BTreeSet};
use std::io::{Read, Write};

use crate::read_int::ReadInt;
use crate::write_int::WriteInt;
use crate::ReadWriteRPC;

/// ReadWrite trait for structs used in contract actions
pub trait ReadWriteState: Sized {
    /// Read method for structs used in contract actions
    fn state_read_from<T: Read>(reader: &mut T) -> Self;

    /// Write method for structs used in contract state
    fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()>;
}

/// Implementation of the ReadWriteState trait for Vec<T> for any T that implements ReadWriteState.
impl<T: ReadWriteState> ReadWriteState for Vec<T> {
    fn state_read_from<R: Read>(reader: &mut R) -> Self {
        let len = reader.read_u32_be() as usize;
        let mut result = Vec::with_capacity(len);
        for _ in 0..len {
            result.push(T::state_read_from(reader))
        }
        result
    }

    fn state_write_to<W: Write>(&self, writer: &mut W) -> std::io::Result<()> {
        writer.write_u32_be(self.len() as u32).unwrap();
        for item in self {
            item.state_write_to(writer).unwrap();
        }

        Ok(())
    }
}

/// Implementation of the ReadWriteState trait for Option<T> for any T that
/// implements ReadWriteState.
impl<T: ReadWriteState> ReadWriteState for Option<T> {
    fn state_read_from<R: Read>(reader: &mut R) -> Self {
        let marker = reader.read_u8();
        match marker {
            0 => None,
            _ => Some(T::state_read_from(reader)),
        }
    }

    fn state_write_to<W: Write>(&self, writer: &mut W) -> std::io::Result<()> {
        match &self {
            None => writer.write_u8(0),
            Some(value) => {
                writer.write_u8(1).unwrap();
                value.state_write_to(writer)
            }
        }
    }
}

/// Implementation of the ReadWriteState trait for BTreeMap<K, V>
/// for any K, V that implement ReadWriteState
impl<K: ReadWriteState + Ord, V: ReadWriteState> ReadWriteState for BTreeMap<K, V> {
    fn state_read_from<R: Read>(reader: &mut R) -> Self {
        let mut result = BTreeMap::new();
        let len = reader.read_u32_be();

        for _ in 0..len {
            let key = K::state_read_from(reader);
            let value = V::state_read_from(reader);
            if result.insert(key, value).is_some() {
                panic!("Duplicate key added");
            }
        }

        result
    }

    fn state_write_to<W: Write>(&self, writer: &mut W) -> std::io::Result<()> {
        writer.write_u32_be(self.len() as u32)?;
        for (key, value) in self.iter() {
            key.state_write_to(writer)?;
            value.state_write_to(writer)?;
        }
        Ok(())
    }
}

/// Implementation of the ReadWriteState trait for BTreeSet<T>
/// for any T that implements ReadWriteState
impl<T: ReadWriteState + Ord> ReadWriteState for BTreeSet<T> {
    fn state_read_from<R: Read>(reader: &mut R) -> Self {
        let mut result = BTreeSet::new();
        let mut previous = None;

        let len = reader.read_u32_be();
        for _ in 0..len {
            let value = T::state_read_from(reader);
            if let Some(prev_value) = previous {
                if value <= prev_value {
                    panic!("Unordered or duplicate key added");
                }
                result.insert(prev_value);
                previous = Some(value)
            } else {
                previous = Some(value);
            }
        }

        if let Some(prev_value) = previous {
            result.insert(prev_value);
        }

        result
    }

    fn state_write_to<W: Write>(&self, writer: &mut W) -> std::io::Result<()> {
        writer.write_u32_be(self.len() as u32)?;
        for value in self.iter() {
            value.state_write_to(writer)?;
        }
        Ok(())
    }
}

/// A macro to derive `ReadWriteState` using the `ReadWriteRPC` implementation of read and write.
#[macro_export]
macro_rules! state_rw_from_rpc {
    ($($type:ty)*) => {
        $(
            #[doc = "Implementation of ReadWriteState-trait for "]
            #[doc = stringify!($type)]
            impl ReadWriteState for $type {
                fn state_read_from<T: Read>(reader: &mut T) -> Self {
                   <$type as ReadWriteRPC>::rpc_read_from(reader)
                }

                fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
                    self.rpc_write_to(writer)
                }
            }
        )*
    }
}

state_rw_from_rpc!(
    String
    u8 u16 u32 u64 i128
    i8 i16 i32 i64 u128
    bool
);

macro_rules! array_impls {
    ($($len:tt)+) => {
        $(
            #[doc = "Implementation of ReadWriteState-trait for the type \\[u8, "]
            #[doc = stringify!($len)]
            #[doc = "\\]"]
            impl ReadWriteState for [u8; $len] {
                fn state_read_from<T: Read>(reader: &mut T) -> Self {
                    <[u8; $len]>::rpc_read_from(reader)
                }

                fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
                    self.rpc_write_to(writer)
                }
            }
        )+
    }
}

array_impls!(
     1  2  3  4  5  6  7  8
     9 10 11 12 13 14 15 16
    17 18 19 20 21 22 23 24
    25 26 27 28 29 30 31 32
);
