use std::collections::{BTreeMap, BTreeSet};

/// This trait adds the runtime type information needed to generate the PBC ABI.
/// See [ABI spec](https://privacyblockchain.gitlab.io/language/rust-contract-sdk/abiv1.html)
///
/// * The `__ty_name()` method returns ordinary Rust names.
/// * The `__ty_ordinal()` method recursively creates the PBC ABI byte-serialized type specification
///
pub trait CreateTypeSpec: Sized {
    /// The name of the type.
    fn __ty_name() -> String;

    /// The type spec ordinal for the type. See docs for `CreateTypeSpec` for more information.
    fn __ty_ordinal(w: &mut Vec<u8>);
}

// Implement the `CreateTypeSpec` trait for a 'simple' type given a type name and a type ordinal.
//
// The input is n pairs of (type, literal).
//
// The output is n implementations of `CreateTypeSpec` that simply write the type as a string
// and fill the ordinal in the `__ty_ordinal()` vector output.
macro_rules! impl_for_type {
    ($($type:ty, $val:literal)*) => {
        $(
            #[doc = "Implementation of the `CreateTypeSpec` trait for "]
            #[doc = stringify!($type)]
            impl CreateTypeSpec for $type {
                fn __ty_name() -> String {
                    format!("{}", quote!($type).to_string())
                }

                fn __ty_ordinal( w: &mut Vec<u8>) {
                    w.push($val)
                }
            }
        )*
    }
}

// Implement the `CreateTypeSpec` trait for all simple types.
// Byte values are taken from the ABI spec.
// Due to macro_rules restrictions we can't have them here as a named constant.
impl_for_type!(
    u8,     0x01
    u16,    0x02
    u32,    0x03
    u64,    0x04
    u128,   0x05
    i8,     0x06
    i16,    0x07
    i32,    0x08
    i64,    0x09
    i128,   0x0a
    String, 0x0b
    bool,   0x0c
);

/// Implementation of the CreateTypeSpec trait for Vec<T> for any T that implements ReadWriteState.
impl<T: CreateTypeSpec> CreateTypeSpec for Vec<T> {
    fn __ty_name() -> String {
        format!("Vec<{}>", T::__ty_name())
    }

    fn __ty_ordinal(w: &mut Vec<u8>) {
        // Vector is 0x0e followed by the spec for the parameter type
        w.push(0x0e);
        T::__ty_ordinal(w);
    }
}

/// Implementation of the CreateTypeSpec trait for for BTreeMap<K, V>
/// for any K, V that implement ReadWriteState.
impl<K: CreateTypeSpec, V: CreateTypeSpec> CreateTypeSpec for BTreeMap<K, V> {
    fn __ty_name() -> String {
        format!("BTreeMap<{}, {}>", K::__ty_name(), V::__ty_name())
    }

    fn __ty_ordinal(w: &mut Vec<u8>) {
        // BTreeMap is 0x0f followed by the spec for key type and then the value type
        w.push(0x0f);
        K::__ty_ordinal(w);
        V::__ty_ordinal(w);
    }
}

/// Implementation of the ReadWriteState trait for BTreeSet<T>
/// for any T that implements ReadWriteState
impl<V: CreateTypeSpec> CreateTypeSpec for BTreeSet<V> {
    fn __ty_name() -> String {
        format!("BTreeSet<{}>", V::__ty_name())
    }

    fn __ty_ordinal(w: &mut Vec<u8>) {
        // BTreeSet is 0x10 followed by the spec for the parameter type
        w.push(0x10);
        V::__ty_ordinal(w);
    }
}

/// Implementation of the ReadWriteState trait for Option<T>
/// for any T that implements ReadWriteState
impl<T: CreateTypeSpec> CreateTypeSpec for Option<T> {
    fn __ty_name() -> String {
        format!("Option<{}>", T::__ty_name())
    }

    fn __ty_ordinal(w: &mut Vec<u8>) {
        // Option is 0x12 followed by the spec for the parameter type
        w.push(0x12);
        T::__ty_ordinal(w);
    }
}

// Implement CreateTypeSpec for an [u8;n] array type.
// The ordinal is 0x11 followed by the length of the array.
macro_rules! impl_for_array_type {
    ($($len:tt)+) => {
        $(
            #[doc = "Implementation of CreateType-trait for the type \\[u8, "]
            #[doc = stringify!($len)]
            #[doc = "\\]"]
            impl CreateTypeSpec for [u8; $len] {
                fn __ty_name() -> String {
                     format!("[u8; {}]", quote!($len).to_string())
                }

                fn __ty_ordinal(w: &mut Vec<u8>) {
                    w.push(0x11);
                    w.push($len);
                }
            }
        )+
    }
}

// Implement the CreateTypeSpec trait for u8 arrays of size 1-32
impl_for_array_type!(
     1  2  3  4  5  6  7  8
     9 10 11 12 13 14 15 16
    17 18 19 20 21 22 23 24
    25 26 27 28 29 30 31 32
);
