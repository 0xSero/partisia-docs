use std::io::Read;
use std::io::Write;

use read_write_state_derive::ReadWriteState;

use crate::address::Address;

/// An interaction is what is sent from an event.
/// It consists of:
///
/// - `dest` - the address of the receiver
/// - `payload` - the raw payload to send to the receiver
/// - `from_contract` - whether to send the interaction from the contract or from the sender of the original transaction
/// - `cost` - the max cost of the interaction.
#[derive(ReadWriteState, Eq, PartialEq, Debug)]
pub struct Interaction {
    dest: Address,
    payload: Vec<u8>,
    from_contract: bool,
    cost: Option<u64>,
}

/// A callback is a simple interaction that is sent *after* all sent events have been processed
/// by a node on the chain.
///
/// - `rpc` - the raw RPC you want to receive
/// - `cost` - the max cost of the callback. If set to `None` the max cost is automatically set from the remaining gas.
#[derive(ReadWriteState, Eq, PartialEq, Debug)]
pub struct Callback {
    rpc: Vec<u8>,
    cost: Option<u64>,
}

/// The event group is a struct holding a list of events to send to other contracts and
/// an optional callback RPC.
///
/// See docs for `Interaction`.
#[derive(ReadWriteState, Eq, PartialEq, Debug)]
pub struct EventGroup {
    callback: Option<Vec<u8>>,
    cost: Option<u64>,
    events: Vec<Interaction>,
}

impl Default for EventGroup {
    fn default() -> Self {
        EventGroup::new()
    }
}

impl EventGroup {
    /// Construct a new empty event group.
    pub fn new() -> EventGroup {
        EventGroup {
            events: Vec::new(),
            callback: None,
            cost: None,
        }
    }

    /// Send an interaction with the contract as sender.
    /// If the cost is set to `None` the cost is automatically set from the remaining gas.
    pub fn send_from_contract(&mut self, dest: &Address, payload: Vec<u8>, cost: Option<u64>) {
        self.events.push(Interaction {
            dest: *dest,
            payload,
            from_contract: true,
            cost,
        })
    }

    /// Send an interaction with the original sender as sender.
    /// If the cost is set to `None` the cost is automatically set from the remaining gas.
    pub fn send_from_original_sender(
        &mut self,
        dest: &Address,
        payload: Vec<u8>,
        cost: Option<u64>,
    ) {
        self.events.push(Interaction {
            dest: *dest,
            payload,
            from_contract: false,
            cost,
        })
    }

    /// Register a callback on this event group.
    /// If the cost is set to `None` the cost is automatically set from the remaining gas.
    pub fn register_callback(&mut self, rpc: Vec<u8>, cost: Option<u64>) {
        self.callback = Some(rpc);
        self.cost = cost;
    }
}

#[cfg(test)]
#[path = "../unit_tests/event_serialization.rs"]
mod event_serialization;
