use std::io::{Read, Write};

use pbc_traits::*;

/// A blockchain address.
#[repr(C)]
#[derive(Eq, PartialEq, Debug, Clone, Ord, PartialOrd, Copy)]
pub enum Address {
    /// Identifies a user/service account. Identifier is prefixed with `0x00`.
    Account(Identifier),
    /// Identifies a system contract. Identifier is prefixed with `0x01`.
    SystemContract(Identifier),
    /// Identifies a public contract. Identifier is prefixed with `0x02`.
    PublicContract(Identifier),
    /// Identifies a zero knowledge contract. Identifier is prefixed with `0x03`.
    ZkContract(Identifier),
}

/// An address identifier is a 20 byte array derived from the hash of the public key of
/// an account.
pub type Identifier = [u8; 20];

impl ReadWriteRPC for Address {
    fn rpc_read_from<T: Read + ReadInt>(reader: &mut T) -> Self {
        let address_type = reader.read_u8();
        let mut content = [0u8; 20];
        reader.read_exact(&mut content).unwrap();

        match address_type {
            0 => Address::Account(content),
            1 => Address::SystemContract(content),
            2 => Address::PublicContract(content),
            3 => Address::ZkContract(content),
            n => {
                panic!("Unrecognized address type {}", n)
            }
        }
    }

    fn rpc_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        match self {
            Address::Account(content) => {
                writer.write_u8(0)?;
                writer.write_all(content)
            }
            Address::SystemContract(content) => {
                writer.write_u8(1)?;
                writer.write_all(content)
            }
            Address::PublicContract(content) => {
                writer.write_u8(2)?;
                writer.write_all(content)
            }
            Address::ZkContract(content) => {
                writer.write_u8(3)?;
                writer.write_all(content)
            }
        }
    }
}

impl ReadWriteState for Address {
    fn state_read_from<T: Read + ReadInt>(reader: &mut T) -> Self {
        <Address as ReadWriteRPC>::rpc_read_from(reader)
    }

    fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.rpc_write_to(writer)
    }
}

impl CreateTypeSpec for Address {
    fn __ty_name() -> String {
        "Address".to_string()
    }

    fn __ty_ordinal(w: &mut Vec<u8>) {
        w.push(0x0d)
    }
}
