//! Common types and methods used in contract programming.
extern crate quote;

use std::collections::BTreeMap;

pub use function_name::FunctionName;
use pbc_external::log_external;
use pbc_traits::ReadWriteState;
pub use raw_ptr::RawPtr;

use crate::abi::TypeKey;
use crate::events::EventGroup;

/// The ABI traits and glue code.
pub mod abi;
/// The address module.
pub mod address;
/// The contract context module.
pub mod context;
/// The events module.
pub mod events;

mod function_name;
mod raw_ptr;

/// The hash type is simply a 32 byte array
pub type Hash = [u8; 32];

/// Write an ABI object to the given pointer.
/// This method uses unsafe code.
#[allow(clippy::not_unsafe_ptr_arg_deref)]
pub fn abi_to_ptr<T: ReadWriteState>(abi: T, pointer: *mut u8) -> u32 {
    let mut raw = RawPtr::new(pointer);
    abi.state_write_to(&mut raw).unwrap();
    raw.get_offset()
}

/// Allocates a vector and writes the result tuple according to what the blockchain expects.
///
/// # Safety
///
/// This writes the result and forgets the buffer so it should only be called
/// as the last part of the transaction.
pub unsafe fn write_result<S: ReadWriteState>(result: (S, Vec<EventGroup>)) -> u64 {
    let (state, events) = result;

    let mut buf: Vec<u8> = Vec::with_capacity(10240);

    // Write the events first struct in reverse order
    events.state_write_to(&mut buf).unwrap();
    state.state_write_to(&mut buf).unwrap();

    let len = buf.len();
    let ptr = buf.as_ptr();

    std::mem::forget(buf);

    (len as u64) << 32 | (ptr as u64)
}

/// Read a type ordinal lookup table from the given memory address.
pub fn read_lut_from_ptr(ptr: *mut u8) -> BTreeMap<TypeKey, u8> {
    let mut read = RawPtr::new(ptr);
    ReadWriteState::state_read_from(&mut read)
}

fn raw_log(message: &str) {
    let string = message.to_string();
    let len = string.len();
    unsafe {
        log_external(string.as_ptr() as i64, len as i32);
    }
}

/// Log a message to the blockchain standard out.
pub fn info(string: String) {
    raw_log(&string);
}
