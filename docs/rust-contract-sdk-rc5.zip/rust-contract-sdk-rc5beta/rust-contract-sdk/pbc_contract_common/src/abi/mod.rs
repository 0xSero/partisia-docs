use std::fmt::{Debug, Display, Formatter};
use std::io::Read;
use std::io::Write;

pub use contract::ContractAbi;
pub use func::FnAbi;
pub use named_entity::NamedEntityAbi;
use pbc_traits::{CreateTypeSpec, WriteInt};
use read_write_state_derive::ReadWriteState;
pub use types::TypeAbi;

mod contract;
mod func;
mod named_entity;
mod types;

/// Semantic version.
/// See https://semver.org/
#[derive(PartialEq)]
pub struct SemVer {
    /// MAJOR version when you make incompatible API changes.
    pub major: u8,
    /// MINOR version when you add functionality in a backwards compatible manner.
    pub minor: u8,
    /// PATCH version when you make backwards compatible bug fixes.
    pub patch: u8,
}

impl SemVer {
    /// Create a new semantic version.
    pub fn new(major: u8, minor: u8, patch: u8) -> SemVer {
        SemVer {
            major,
            minor,
            patch,
        }
    }
}

impl Display for SemVer {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}.{}.{}", self.major, self.minor, self.patch)
    }
}

impl Debug for SemVer {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}.{}.{}", self.major, self.minor, self.patch)
    }
}

/// PBC Version of the binary format used by the PBC WASM binder.
/// This versions the format of the binary data that the PBC WASM binder reads when handling smart
/// contracts.
pub static VERSION_BINDER: SemVer = SemVer {
    major: 1,
    minor: 0,
    patch: 0,
};

/// PBC Version of the binary format used by blockchain clients.
/// This versions the format of the binary data that smart contract code read/write to the contract
/// state and the binary data received/sent in transactions/events.
pub static VERSION_CLIENT: SemVer = SemVer {
    major: 1,
    minor: 0,
    patch: 0,
};

/// Serialize this struct according to the ABI specification.
///
/// * `slice` - the slice of T's to write to the stream
/// * `writer` - the writer
///
pub fn abi_serialize_slice<T: AbiSerialize, W: Write>(
    slice: &[T],
    writer: &mut W,
) -> std::io::Result<()> {
    writer.write_u32_be(slice.len() as u32)?;
    for t in slice.iter() {
        AbiSerialize::serialize_abi(t, writer)?;
    }
    Ok(())
}

/// A small struct that uniquely identifies a Rust type within the PBC ABI.
#[derive(ReadWriteState, Eq, PartialEq, Debug, PartialOrd, Ord, Clone)]
pub struct TypeKey {
    /// The name of the represented type.
    name: String,
    /// The list of ordinals identifying the represented type.
    pub ordinals: Vec<u8>,
}

impl TypeKey {
    /// Instantiate a new `TypeKey`, infer arguments.
    pub fn new<T: CreateTypeSpec>() -> TypeKey {
        let name = T::__ty_name();
        let mut ordinals = Vec::new();
        T::__ty_ordinal(&mut ordinals);

        TypeKey { name, ordinals }
    }
}

/// A trait for serializing ABI objects.
/// This is different from `ReadWriteState` and `ReadWriteRPC` since it is intended
/// for serializing across the FFI layer between contracts and `pbc-abigen`.
/// It does not serialize struct fields directly, but according to the ABI specification.
pub trait AbiSerialize {
    /// Serialize the ABI to the given writer.
    fn serialize_abi<T: Write>(&self, writer: &mut T) -> std::io::Result<()>;
}
