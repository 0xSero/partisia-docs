use std::collections::BTreeMap;
use std::io::{Read, Write};

use pbc_traits::{CreateTypeSpec, ReadWriteRPC, WriteInt};
use read_write_state_derive::ReadWriteState;

use crate::abi::{AbiSerialize, TypeKey};

/// A struct representing any (name, type) entity.
/// In this case it is function arguments and struct fields.
#[derive(PartialEq, Eq, Debug, ReadWriteState)]
pub struct NamedEntityAbi {
    /// The name of the field or argument.
    pub name: String,
    /// The type ordinals for the type of the argument.
    pub type_ordinals: Vec<u8>,
    /// The type index should one exist.
    pub type_index: Option<u8>,
}

impl NamedEntityAbi {
    /// Instantiate a `NamedEntityAbi` with  the specified name.
    ///
    /// * `name` - the name of the type.
    /// * `lut` - the lookup table for the ABI generation. See `pbc-abigen` for details.
    pub fn new<T: CreateTypeSpec>(name: String, lut: &BTreeMap<TypeKey, u8>) -> Self {
        let mut type_ordinals = Vec::new();
        T::__ty_ordinal(&mut type_ordinals);

        let type_key = TypeKey::new::<T>();
        let type_index = lut.get(&type_key).copied();

        NamedEntityAbi {
            name,
            type_ordinals,
            type_index,
        }
    }
}

impl AbiSerialize for NamedEntityAbi {
    fn serialize_abi<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.name.rpc_write_to(writer)?;
        for ord in self.type_ordinals.iter() {
            writer.write_u8(*ord)?;
        }

        if let Some(idx) = self.type_index {
            writer.write_u8(idx)?;
        }

        Ok(())
    }
}

#[cfg(test)]
mod test {
    use pbc_traits::ReadWriteState;

    use crate::abi::NamedEntityAbi;
    use std::collections::BTreeMap;

    #[test]
    fn read_write_state_smoke_test() {
        let lut = BTreeMap::new();
        let abi = NamedEntityAbi::new::<String>("my_name".to_string(), &lut);

        let mut output: Vec<u8> = Vec::new();
        abi.state_write_to(&mut output).unwrap();

        assert_eq!(
            output,
            vec![0, 0, 0, 7, 109, 121, 95, 110, 97, 109, 101, 0, 0, 0, 1, 11, 0]
        )
    }
}
