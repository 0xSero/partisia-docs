extern crate sha2;

use std::collections::BTreeMap;
use std::io::{Read, Write};

use pbc_traits::{CreateTypeSpec, ReadInt, ReadWriteState, WriteInt};

use crate::abi::NamedEntityAbi;
use crate::abi::{abi_serialize_slice, AbiSerialize};
use crate::{FunctionName, TypeKey};

/// A struct representing a function in the ABI.
#[derive(PartialEq, Eq)]
pub struct FnAbi {
    name: FunctionName,
    args: Vec<NamedEntityAbi>,
}

impl FnAbi {
    /// Create a function abi with the supplied name.
    pub fn new(name: String) -> Self {
        let args = Vec::new();
        FnAbi {
            name: FunctionName::new(name),
            args,
        }
    }

    /// Add an argument to this instance. Types are inferred.
    ///
    /// * `name` - the name of the type.
    /// * `lut` - the lookup table for the ABI generation. See `pbc-abigen` for details.
    pub fn argument<T: CreateTypeSpec>(&mut self, name: String, lut: &BTreeMap<TypeKey, u8>) {
        self.args.push(NamedEntityAbi::new::<T>(name, lut));
    }
}

impl AbiSerialize for FnAbi {
    fn serialize_abi<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.name.serialize_abi(writer)?;
        abi_serialize_slice(&self.args, writer)
    }
}

impl ReadWriteState for FnAbi {
    fn state_read_from<T: Read>(reader: &mut T) -> Self {
        let mut fn_abi = FnAbi {
            name: FunctionName::state_read_from(reader),
            args: Vec::new(),
        };

        let field_count = reader.read_u32_be();
        for _ in 0..field_count {
            fn_abi.args.push(NamedEntityAbi::state_read_from(reader));
        }
        fn_abi
    }

    fn state_write_to<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.name.state_write_to(writer)?;
        writer.write_u32_be(self.args.len() as u32)?;
        for arg in self.args.iter() {
            arg.state_write_to(writer)?;
        }
        Ok(())
    }
}
