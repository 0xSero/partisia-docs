use std::io::{Read, Write};

use pbc_traits::{CreateTypeSpec, ReadWriteRPC};
use read_write_state_derive::ReadWriteState;

use crate::abi::{abi_serialize_slice, AbiSerialize, NamedEntityAbi};
use crate::TypeKey;

/// A struct representing the ABI for a Rust type.
#[derive(PartialEq, Debug, Eq, ReadWriteState)]
pub struct TypeAbi {
    /// The name of the type.
    pub name: String,
    /// The type key, a unique key for identifying the represented Rust type in the ABI.
    pub type_key: TypeKey,
    /// The list of the fields that are associated with this type.
    pub fields: Vec<NamedEntityAbi>,
}

impl TypeAbi {
    /// Construct a new `TypeAbi` instance with the specified name.
    pub fn new<T: CreateTypeSpec>(name: String) -> Self {
        let fields = Vec::new();
        let mut type_ordinals = Vec::new();
        T::__ty_ordinal(&mut type_ordinals);
        TypeAbi {
            name,
            type_key: TypeKey::new::<T>(),
            fields,
        }
    }

    /// Add a field to this `TypeAbi` instance.
    pub fn field(&mut self, field: NamedEntityAbi) {
        self.fields.push(field);
    }
}

impl AbiSerialize for TypeAbi {
    fn serialize_abi<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.name.rpc_write_to(writer)?;
        abi_serialize_slice(&self.fields, writer)
    }
}
