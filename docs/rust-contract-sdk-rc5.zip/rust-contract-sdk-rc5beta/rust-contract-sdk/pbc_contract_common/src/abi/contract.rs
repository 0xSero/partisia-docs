use std::io::{Read, Write};

use pbc_traits::WriteInt;
use read_write_state_derive::ReadWriteState;

use crate::abi::{abi_serialize_slice, AbiSerialize, FnAbi, TypeAbi};

/// The `ContractAbi` describes the ABI for a contract including all the actions
/// in the contract and the contract state + all user-defined structs within the state and actions.
#[derive(PartialEq, Eq, ReadWriteState)]
pub struct ContractAbi {
    shortname_length: u8,
    types: Vec<TypeAbi>,
    init: FnAbi,
    actions: Vec<FnAbi>,
    state: Vec<u8>,
}

impl ContractAbi {
    /// Construct a new `ContractAbi` with the specified init function and state type ordinal list.
    pub fn new(init: FnAbi, state: Vec<u8>) -> Self {
        let actions = Vec::new();
        let types = Vec::new();
        ContractAbi {
            shortname_length: 4,
            init,
            actions,
            state,
            types,
        }
    }

    /// Set the actions of this `ContractAbi` instance to the supplied vector.
    pub fn actions(&mut self, actions: Vec<FnAbi>) {
        self.actions = actions;
    }

    /// Set the types of this `ContractAbi` instance to the supplied vector.
    pub fn types(&mut self, types: Vec<TypeAbi>) {
        self.types = types;
    }

    /// Serialize this struct according to the ABI specification.
    pub fn serialize_abi<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        writer.write_u8(self.shortname_length)?;
        abi_serialize_slice(&self.types, writer)?;
        self.init.serialize_abi(writer)?;
        abi_serialize_slice(&self.actions, writer)?;
        writer.write_all(&self.state)
    }
}
