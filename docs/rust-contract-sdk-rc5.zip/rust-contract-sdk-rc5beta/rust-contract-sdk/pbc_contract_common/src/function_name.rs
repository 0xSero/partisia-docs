use std::io::Read;
use std::io::Write;

use pbc_traits::ReadWriteState;
use read_write_state_derive::ReadWriteState;
use sha2::{Digest, Sha256};

use crate::abi::AbiSerialize;

/// A small struct that automatically calculates the shortname of a function.
#[derive(ReadWriteState, PartialEq, Eq)]
pub struct FunctionName {
    name: String,
    shortname: u32,
}

impl FunctionName {
    /// Create a new instance with the specified name. The shortname is calculated eagerly.
    pub fn new(name: String) -> FunctionName {
        FunctionName::create_from_str(&name)
    }

    /// Create a new instance with the specified name as a str. The shortname is calculated eagerly.
    pub fn create_from_str(name: &str) -> FunctionName {
        let shortname = name_to_shortname(name);
        FunctionName {
            name: name.to_string(),
            shortname,
        }
    }

    /// Get the shortname as a lowercase hex string.
    pub fn shortname_as_string(&self) -> String {
        format!("{:x}", self.shortname)
    }

    /// Get the shortname as the raw u32 int.
    pub fn shortname_as_int(&self) -> u32 {
        self.shortname
    }
}

impl AbiSerialize for FunctionName {
    fn serialize_abi<T: Write>(&self, writer: &mut T) -> std::io::Result<()> {
        self.name.state_write_to(writer)
    }
}

/// Create a shortname from the given function name.
/// The shortname consists of the first 4 bytes of the SHA256 hash of the name.
fn name_to_shortname(raw_name: &str) -> u32 {
    let mut digest = Sha256::new();
    Digest::update(&mut digest, raw_name.as_bytes());
    let output = digest.finalize();
    let first_four = output.chunks(4).next().unwrap();
    u32::from_be_bytes(first_four.try_into().unwrap())
}

#[cfg(test)]
mod test {
    use std::io::Cursor;

    use pbc_traits::ReadWriteState;

    use crate::FunctionName;

    #[test]
    fn read_write_state_smoke_test() {
        let abi = FunctionName::new("my_name".to_string());

        let mut output: Vec<u8> = Vec::new();
        abi.state_write_to(&mut output).unwrap();

        assert_eq!(
            output,
            vec![0, 0, 0, 7, 109, 121, 95, 110, 97, 109, 101, 111, 117, 15, 166]
        );

        let mut cursor = Cursor::new(output);
        let actual: FunctionName = ReadWriteState::state_read_from(&mut cursor);

        assert_eq!(actual.name, abi.name);
        assert_eq!(actual.shortname, abi.shortname);
    }
}
