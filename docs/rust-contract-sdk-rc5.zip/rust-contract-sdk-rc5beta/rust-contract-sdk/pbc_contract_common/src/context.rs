use std::io::{Error, ErrorKind, Read, Write};

use pbc_traits::{ReadInt, ReadWriteState};

use crate::address::Address;
use crate::Hash;

/// The contract context encapsulates the blockchain state and relevant information
/// for the callee.
#[repr(C)]
#[derive(Eq, PartialEq, Debug)]
pub struct ContractContext {
    /// The address of the contract being called.
    pub contract_address: Address,

    /// The sender of the transaction.
    pub sender: Address,

    /// The block time.
    pub block_time: i64,

    /// The block production time in millis UTC.
    pub block_production_time: i64,

    /// The hash of the current transaction.
    pub current_transaction: Hash,

    /// The hash of the parent transaction, if available.
    pub original_transaction: Hash,
}

/// Due to the limitations of the code generation `state_read_from` is required for ContractContext.
impl ReadWriteState for ContractContext {
    fn state_read_from<T: Read>(reader: &mut T) -> Self {
        ContractContext {
            contract_address: Address::state_read_from(reader),
            sender: Address::state_read_from(reader),
            block_time: reader.read_i64_be(),
            block_production_time: reader.read_i64_be(),
            current_transaction: Hash::state_read_from(reader),
            original_transaction: Hash::state_read_from(reader),
        }
    }

    fn state_write_to<T: Write>(&self, _writer: &mut T) -> std::io::Result<()> {
        Err(Error::new(ErrorKind::Unsupported, "Unsupported"))
    }
}
