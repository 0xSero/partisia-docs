use pbc_traits::ReadWriteState;

use crate::address::Address;
use crate::events::Interaction;

fn to_bytes<T: ReadWriteState>(val: T) -> Vec<u8> {
    let mut vec = Vec::new();
    val.state_write_to(&mut vec).unwrap();
    vec
}

#[test]
pub fn single_interaction_with_cost() {
    let interaction = Interaction {
        dest: Address::PublicContract([1; 20]),
        cost: Some(42),
        from_contract: false,
        payload: vec![1, 2, 3, 4, 5, 6, 7, 8],
    };

    let vec1 = to_bytes(interaction);
    assert_eq!(
        vec1,
        vec![
            2, // Address type
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, // Address ident
            0, 0, 0, 8, // Payload len
            1, 2, 3, 4, 5, 6, 7, 8, // payload
            0, // Send from sender
            1, // Cost exists
            0, 0, 0, 0, 0, 0, 0, 42, // Cost is 42
        ]
    );
}

#[test]
pub fn single_interaction_with_no_cost() {
    let interaction = Interaction {
        dest: Address::PublicContract([1; 20]),
        cost: None,
        from_contract: true,
        payload: vec![1, 2, 3, 4, 5, 6, 7, 8],
    };

    let vec1 = to_bytes(interaction);
    assert_eq!(
        vec1,
        vec![
            2, // Address type
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, // Address ident
            0, 0, 0, 8, // Payload len
            1, 2, 3, 4, 5, 6, 7, 8, // payload
            1, // Send from contract
            0, // Cost does not exist
        ]
    );
}
