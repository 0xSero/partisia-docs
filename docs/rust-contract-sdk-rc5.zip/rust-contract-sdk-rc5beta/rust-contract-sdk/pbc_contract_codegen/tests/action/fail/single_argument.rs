#![no_main]
use pbc_contract_codegen::{action};
use pbc_contract_common::context::ContractContext;

#[action]
pub fn action(_context: ContractContext) {}
