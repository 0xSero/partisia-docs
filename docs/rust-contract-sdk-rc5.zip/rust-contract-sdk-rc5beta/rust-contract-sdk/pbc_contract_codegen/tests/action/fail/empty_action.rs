#![no_main]
use pbc_contract_codegen::{action};

#[action]
pub fn action() {}
