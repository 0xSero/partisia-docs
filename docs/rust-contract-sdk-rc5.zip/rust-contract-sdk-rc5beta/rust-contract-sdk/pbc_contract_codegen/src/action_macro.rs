use proc_macro::TokenStream;

use pbc_contract_common::FunctionName;
use proc_macro2::Ident;
use syn::ItemFn;

use crate::{
    read_arguments_names_and_types, variables_for_inner_call, wrap_function_for_export,
    TokenStream2,
};

pub fn handle_action_macro(input: TokenStream) -> TokenStream {
    let fn_ast: syn::ItemFn = syn::parse(input.clone()).unwrap();

    let fn_identifier: &Ident = &fn_ast.sig.ident;
    let function_name = FunctionName::new(fn_identifier.to_string());
    let shortname = function_name.shortname_as_string();

    let to_ptr_stream = make_fn_to_ptr_stream(&shortname);
    let func_stream = create_abi_for_fn(&fn_ast, &shortname);

    let docs = format!("For contract action: {}", fn_identifier);

    let export_symbol = format_ident!("action_{}", shortname);
    let invocation = variables_for_inner_call(&fn_ast, false);
    let mut result = wrap_function_for_export(fn_identifier, export_symbol, docs, invocation);
    result.extend(TokenStream2::from(input));
    result.extend(func_stream);
    result.extend(to_ptr_stream);
    result.into()
}

fn create_abi_for_fn(fn_ast: &ItemFn, shortname: &str) -> TokenStream2 {
    let name = format_ident!("__abi_fn_{}", shortname);
    let fn_name = &fn_ast.sig.ident.to_string();

    let (params, types) = read_arguments_names_and_types(fn_ast, 2).convert_to_tuple();
    quote! {
        pub fn #name(lut_ptr: *mut u8) -> pbc_contract_common::abi::FnAbi {
            let lut = pbc_contract_common::read_lut_from_ptr(lut_ptr);

            let mut fn_abi = pbc_contract_common::abi::FnAbi::new(#fn_name.to_string());
            #(fn_abi.argument::<#types>(#params.to_string(), &lut);)*
            fn_abi
        }
    }
}

fn make_fn_to_ptr_stream(shortname: &str) -> proc_macro2::TokenStream {
    let delegated_function_to_call = format_ident!("__abi_fn_{}", shortname);
    let function_name = format_ident!("__abi_fn_to_ptr_{}", shortname);
    let result = quote! {
        #[no_mangle]
        pub extern "C" fn #function_name(ptr: *mut u8, lut_ptr: *mut u8) -> u32 {
            let abi = #delegated_function_to_call(lut_ptr);
            pbc_contract_common::abi_to_ptr(abi, ptr)
        }
    };
    result
}
