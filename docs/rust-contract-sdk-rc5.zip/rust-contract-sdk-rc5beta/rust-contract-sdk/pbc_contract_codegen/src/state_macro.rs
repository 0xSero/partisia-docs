use proc_macro::TokenStream;

use syn::Item;
use syn::__private::TokenStream2;

/// This handles the actual state struct AST with regards to it being a contract state.
///
/// First it adds derives for `CreateTypeSpec` and `ReadWriteState` on the struct.
///
/// Second it generates a method named `__abi_state_name` that can be used to identify
/// the state in the types table during ABI generation.
pub(crate) fn handle_state_macro(input: TokenStream) -> TokenStream {
    let original_state_struct: proc_macro2::TokenStream = input.clone().into();
    let struct_ast: Item = syn::parse(input).unwrap();

    let state_struct_name = match struct_ast {
        Item::Struct(i) => i.ident.to_string(),
        _ => unimplemented!("The state attribute is only valid for structs."),
    };

    let stamped_versions = crate::version::create_version_numbers();
    let result: TokenStream2 = quote! {
        use create_type_spec_derive::CreateTypeSpec as InternalDeriveCreateType;
        use read_write_state_derive::ReadWriteState as InternalDeriveReadWriteState;

        #stamped_versions

        #[repr(C)]
        #[derive(Clone, InternalDeriveCreateType, InternalDeriveReadWriteState)]
        #original_state_struct

        #[doc = "ABI: Name of the state struct"]
        #[no_mangle]
        #[allow(clippy::not_unsafe_ptr_arg_deref)]
        pub extern "C" fn __abi_state_name(dst_ptr: *mut u8, _unused_lut_ptr: *mut u8) -> u32 {
            let state_name = #state_struct_name.to_string();
            pbc_contract_common::abi_to_ptr(state_name, dst_ptr)
        }
    };

    // Convert the token from quote into the proc macro token stream
    result.into()
}
