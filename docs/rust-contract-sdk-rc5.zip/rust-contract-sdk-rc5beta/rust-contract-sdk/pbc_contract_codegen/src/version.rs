use pbc_contract_common::abi::SemVer;
use pbc_contract_common::abi::VERSION_BINDER;
use pbc_contract_common::abi::VERSION_CLIENT;
use proc_macro2::{Ident, TokenStream};

pub(crate) fn create_version_numbers() -> TokenStream {
    let mut result = create_client_version();
    result.extend(create_binder_version());
    result
}

fn create_client_version() -> TokenStream {
    let name = version_name("CLIENT", &VERSION_CLIENT);
    quote! {
        #[doc = "PBC Version of the binary format used by blockchain clients."]
        #[doc = "This versions the format of the binary data that smart contract code read/write to the contract state and the binary data received/sent in transactions/events."]
        #[no_mangle]
        pub static #name : () = ();
    }
}

fn create_binder_version() -> TokenStream {
    let name = version_name("BINDER", &VERSION_BINDER);
    quote! {
        #[doc = "PBC Version of the binary format used by the PBC WASM binder."]
        #[doc = "This versions the format of the binary data that the PBC WASM binder reads when handling smart contracts."]
        #[no_mangle]
        pub static #name : () = ();
    }
}

fn version_name(version_type: &str, version: &SemVer) -> Ident {
    format_ident!(
        "__PBC_VERSION_{}_{}_{}_{}",
        version_type,
        version.major,
        version.minor,
        version.patch
    )
}
