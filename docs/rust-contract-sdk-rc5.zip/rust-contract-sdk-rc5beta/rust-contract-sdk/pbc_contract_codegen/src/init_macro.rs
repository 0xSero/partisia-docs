use crate::{
    read_arguments_names_and_types, variables_for_inner_call, wrap_function_for_export,
    TokenStream2,
};
use proc_macro::TokenStream;

pub fn handle_init_macro(input: TokenStream) -> TokenStream {
    let fn_ast: syn::ItemFn = syn::parse(input.clone()).unwrap();
    let invocation = variables_for_inner_call(&fn_ast, true);

    let fn_identifier = fn_ast.sig.ident.clone();
    let export_symbol = format_ident!("init");
    let raw_fn_name = fn_identifier.to_string();
    let docs = format!("For contract initializer: {}", raw_fn_name);

    let mut result = wrap_function_for_export(&fn_identifier, export_symbol, docs, invocation);

    let arguments = read_arguments_names_and_types(&fn_ast, 1);
    let (names, types_as_string) = arguments.convert_to_tuple();

    let types_as_ident: Vec<TokenStream2> = types_as_string.into_iter().collect();

    let internal_abi_fn = quote! {
        #[doc = "ABI: Init function abi"]
        #[no_mangle]
        pub extern "C" fn __abi_func_init_to_ptr(ptr: *mut u8, lut_ptr: *mut u8) -> u32 {
            let lut = pbc_contract_common::read_lut_from_ptr(lut_ptr);
            let mut fn_abi = pbc_contract_common::abi::FnAbi::new(#raw_fn_name.to_string());
            #(fn_abi.argument::<#types_as_ident>(#names.to_string(), &lut);)*
            pbc_contract_common::abi_to_ptr(fn_abi, ptr)
        }
    };

    result.extend(internal_abi_fn);
    result.extend(TokenStream2::from(input));
    result.into()
}
