//! The codegen crate generates a lot of boilerplate code for a Rust smart contract.
#![recursion_limit = "128"]
extern crate pbc_external;
extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate sha2;
extern crate syn;

use proc_macro::TokenStream;

use quote::ToTokens;
use syn::__private::TokenStream2;
use syn::{FnArg, Ident, Type, TypeArray, TypePath};

use crate::tokenized::{ArgumentList, InstantiableArgument, TokenizedInvocation};

mod action_macro;
mod init_macro;
mod state_macro;
mod tokenized;
mod version;

/// The state macro generates the relevant code for the contract state struct.
/// See `state_macro::handle_state_macro`.
#[proc_macro_attribute]
pub fn state(_attrs: TokenStream, input: TokenStream) -> TokenStream {
    state_macro::handle_state_macro(input)
}

/// Mark a function as the initializer in the contract.
#[proc_macro_attribute]
pub fn init(_attrs: TokenStream, input: TokenStream) -> TokenStream {
    init_macro::handle_init_macro(input)
}

/// Mark a function as an action in the contract.
#[proc_macro_attribute]
pub fn action(_attrs: TokenStream, input: TokenStream) -> TokenStream {
    action_macro::handle_action_macro(input)
}

#[allow(clippy::too_many_arguments)]
fn wrap_function_for_export(
    fn_identifier: &Ident,
    export_symbol: Ident,
    docs: String,
    arguments: TokenizedInvocation,
) -> TokenStream2 {
    let rpc_params = &arguments.param_instantiation_expr();
    let rpc_param_names = &arguments.param_names();
    let ctx_expression = arguments.context.expression;

    if arguments.state.is_some() {
        let state_expression = arguments.state.unwrap().expression;
        quote! {
            #[allow(clippy::not_unsafe_ptr_arg_deref)]
            #[doc = #docs]
            #[no_mangle]
            pub extern "C" fn #export_symbol(
                ctx_ptr: *mut u8, ctx_len: usize,
                state_ptr: *mut u8, state_len: usize,
                rpc_ptr: *mut u8, rpc_len: usize
            ) -> u64 {
                #rpc_params

                let mut ctx_reader = pbc_contract_common::RawPtr::new(ctx_ptr);
                let context = #ctx_expression;

                let mut state_reader = pbc_contract_common::RawPtr::new(state_ptr);
                let prev_state = #state_expression;

                let result = #fn_identifier(context, prev_state, #(#rpc_param_names),*);

                unsafe { pbc_contract_common::write_result(result) }
            }
        }
    } else {
        quote! {
            #[allow(clippy::not_unsafe_ptr_arg_deref)]
            #[doc = #docs]
            #[no_mangle]
            pub extern "C" fn #export_symbol(
                ctx_ptr: *mut u8, ctx_len: usize,
                rpc_ptr: *mut u8, rpc_len: usize
            ) -> u64 {
                #rpc_params

                let mut ctx_reader = pbc_contract_common::RawPtr::new(ctx_ptr);
                let context = #ctx_expression;

                let result = #fn_identifier(context,  #(#rpc_param_names),*);

                unsafe { pbc_contract_common::write_result(result) }
            }
        }
    }
}

fn variables_for_inner_call(item: &syn::ItemFn, is_init: bool) -> TokenizedInvocation {
    let mut item_iterator = item.sig.inputs.iter();
    let ctx = read_arguments_for_instantiation(
        format_ident!("ctx_reader"),
        item_iterator.next().unwrap(),
        true,
    );
    let state = if is_init {
        None
    } else {
        let state_tmp = read_arguments_for_instantiation(
            format_ident!("state_reader"),
            item_iterator.next().unwrap(),
            true,
        );
        Some(state_tmp)
    };

    let mut arguments = TokenizedInvocation::new(ctx, state);
    for token in item_iterator {
        let reader_ident = format_ident!("rpc_reader");
        let token: InstantiableArgument =
            read_arguments_for_instantiation(reader_ident, token, false);

        arguments.push_param(token)
    }

    arguments
}

/// Read the arguments from the given function AST.
///
/// * `item` - the parsed function
/// * `skip` - number of leading items to skip
fn read_arguments_names_and_types(item: &syn::ItemFn, skip: usize) -> ArgumentList {
    let mut arguments = ArgumentList::new();
    for token in item.sig.inputs.iter() {
        match token {
            FnArg::Receiver(_) => {
                panic!("Contract functions must be bare functions.")
            }

            FnArg::Typed(pat) => {
                let identifier = pat.pat.to_token_stream();
                let ty = pat.ty.to_token_stream();
                arguments.push(identifier, ty);
            }
        }
    }

    arguments.split_off(skip)
}

fn read_arguments_for_instantiation(
    reader_ident: Ident,
    token: &FnArg,
    is_state: bool,
) -> InstantiableArgument {
    match token {
        FnArg::Receiver(_) => {
            panic!("Contract functions must be bare functions.")
        }
        FnArg::Typed(pat) => {
            let name = pat.pat.to_token_stream();
            let var_name = format_ident!("tmp_{}", name.to_string());

            let ty = *(pat.ty.clone());
            match ty {
                Type::Path(path) => {
                    let expr = generate_read_from_path_expression(reader_ident, path, is_state);
                    InstantiableArgument::new(quote! { #var_name }, expr)
                }

                Type::Tuple(_) => {
                    panic!("Unsupported tuple type");
                }

                Type::Array(array) => {
                    let expr = generate_read_from_array_expression(reader_ident, array, is_state);
                    InstantiableArgument::new(quote! { #var_name }, expr)
                }

                Type::ImplTrait(_) => {
                    panic!("Unsupported impl trait type");
                }

                Type::Reference(_) => {
                    panic!("Unsupported reference type");
                }

                Type::Slice(_) => {
                    panic!("Unsupported slice type");
                }

                _ => {
                    panic!("Unsupported argument type.")
                }
            }
        }
    }
}

/// Generate instantiating expressions for the given type.
///
/// This is a part of a macro and assumes that `reader_ident` is in scope where the macro is called
/// and that said ident represents an instance of std::io::Read.
///
/// * `reader_ident` - the reader variable/expression
/// * `path` - the AST type to generate an instantiating expression for
/// * `is_state` - whether we are using `pbc_traits::ReadWriteState` or `pbc_traits::ReadWriteRpc`
fn generate_read_from_path_expression(
    reader_ident: Ident,
    path: TypePath,
    is_state: bool,
) -> TokenStream2 {
    let (trait_type, read_from) = if is_state {
        (quote!(pbc_traits::ReadWriteState), quote!(state_read_from))
    } else {
        (quote!(pbc_traits::ReadWriteRPC), quote!(rpc_read_from))
    };
    match path.path.get_ident() {
        Some(ident) => {
            quote! {<#ident as #trait_type>::#read_from(&mut #reader_ident);}
        }
        None => {
            let type_name = path.into_token_stream();
            quote! {<#type_name as #trait_type>::#read_from(&mut #reader_ident);}
        }
    }
}

/// Generate instantiating expressions for the given array.
///
/// This is a part of a macro and assumes that `reader_ident` is in scope where the macro is called
/// and that said ident represents an instance of std::io::Read.
///
/// * `reader_ident` - the reader variable/expression
/// * `path` - the AST type to generate an instantiating expression for
/// * `is_state` - whether we are using `pbc_traits::ReadWriteState` or `pbc_traits::ReadWriteRpc`
fn generate_read_from_array_expression(
    reader_ident: Ident,
    array: TypeArray,
    is_state: bool,
) -> TokenStream2 {
    let (trait_type, read_from) = if is_state {
        (quote!(pbc_traits::ReadWriteState), quote!(state_read_from))
    } else {
        (quote!(pbc_traits::ReadWriteRPC), quote!(rpc_read_from))
    };

    let array_tokens = array.to_token_stream();
    quote! { <#array_tokens as #trait_type>::#read_from(&mut #reader_ident); }
}

#[cfg(test)]
mod test {
    #[test]
    fn failing_actions() {
        let t = trybuild::TestCases::new();
        t.compile_fail("tests/action/fail/*.rs");
    }
}
