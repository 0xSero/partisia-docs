use crate::TokenStream2;

pub(crate) struct InstantiableArgument {
    pub(crate) name: TokenStream2,
    pub(crate) expression: TokenStream2,
}

impl InstantiableArgument {
    pub(crate) fn new(name: TokenStream2, expression: TokenStream2) -> InstantiableArgument {
        InstantiableArgument { name, expression }
    }
}

pub(crate) struct ArgumentList {
    names: Vec<TokenStream2>,
    expressions: Vec<TokenStream2>,
}

impl ArgumentList {
    pub(crate) fn new() -> ArgumentList {
        ArgumentList {
            names: Vec::new(),
            expressions: Vec::new(),
        }
    }

    pub(crate) fn push(&mut self, name: TokenStream2, expression: TokenStream2) {
        self.names.push(name);
        self.expressions.push(expression);
    }

    pub(crate) fn convert_to_tuple(self) -> (Vec<String>, Vec<TokenStream2>) {
        let as_strings = self.names.iter().map(|token| token.to_string()).collect();

        (as_strings, self.expressions)
    }

    pub(crate) fn split_off(&mut self, at: usize) -> ArgumentList {
        ArgumentList {
            names: self.names.split_off(at),
            expressions: self.expressions.split_off(at),
        }
    }
}

pub(crate) struct TokenizedInvocation {
    pub(crate) context: InstantiableArgument,
    pub(crate) state: Option<InstantiableArgument>,
    pub(crate) params: Vec<InstantiableArgument>,
}

impl TokenizedInvocation {
    pub(crate) fn new(
        context: InstantiableArgument,
        state: Option<InstantiableArgument>,
    ) -> TokenizedInvocation {
        TokenizedInvocation {
            context,
            state,
            params: Vec::new(),
        }
    }

    pub(crate) fn push_param(&mut self, arg: InstantiableArgument) {
        self.params.push(arg);
    }

    pub(crate) fn param_names(&self) -> Vec<TokenStream2> {
        self.params.iter().map(|token| token.name.clone()).collect()
    }

    pub(crate) fn param_instantiation_expr(&self) -> TokenStream2 {
        let rpc_param_names = self.param_names();

        let rpc_param_expressions: Vec<TokenStream2> = self
            .params
            .iter()
            .map(|token| token.expression.clone())
            .collect();

        // The expressions, which are used to evaluate the arguments for the inner function,
        // deserialize from "cursor" meaning they have side effects.
        // Because of this, we need to ensure that they are evaluated in the correct order,
        // thus we will bind them to variables instead of #fn_identifier(#(#expression),*)
        // (since function arguments are not guaranteed to evaluate left to right).
        quote! {
            let mut rpc_reader = pbc_contract_common::RawPtr::new(rpc_ptr);
            #(let #rpc_param_names = #rpc_param_expressions)*
        }
    }
}
