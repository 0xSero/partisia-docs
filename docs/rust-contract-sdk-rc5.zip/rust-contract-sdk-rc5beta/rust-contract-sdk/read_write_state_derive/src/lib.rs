//! A crate for deriving `ReadWriteState`.
extern crate derive_commons;
extern crate proc_macro;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro::TokenStream;

use derive_commons::impl_read_write;

/// Implement `ReadWriteState` for the annotated struct.
#[proc_macro_derive(ReadWriteState)]
pub fn read_write(input: TokenStream) -> TokenStream {
    // Parse the string representation
    let ast = syn::parse(input).unwrap();

    // Build the impl
    let gen = impl_read_write(
        &ast,
        format_ident!("ReadWriteState"),
        format_ident!("state_read_from"),
        format_ident!("state_write_to"),
    );

    // Return the generated impl
    gen.into()
}
